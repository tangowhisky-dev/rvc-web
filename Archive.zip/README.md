# Beatrice Trainer Batch Processing

This directory contains scripts for batch processing audio files with the Beatrice voice conversion trainer.

## Files

- `chunk_audio.py`: Splits a single audio file into 4-second chunks organized by speaker
- `run_beatrice.sh`: Batch processing script that splits audio and runs training
- `README.md`: This file

## Usage

### Single File Splitting

```bash
# Split one audio file into 4-second chunks
# Chunks are saved in a folder named after the speaker
python3 chunk_audio.py input.wav output_dir/ speaker_001
```

Arguments:
- `input.wav`: Audio file (any format: wav, mp3, flac, etc.)
- `output_dir/`: Directory to save chunks
- `speaker_001`: Speaker name/folder (e.g., "speaker_001", "speaker_002")

If speaker name is not provided, it auto-generates from filename (e.g., `speaker_003`).

This will:
- Load `input.wav` (any format)
- Split into 4-second chunks
- Save chunks as `chunk_000000.wav`, `chunk_000001.wav`, etc. in `output_dir/speaker_001/`
- Move original file to `output_dir/../backup/original_input.wav`

**Beatrice trainer expects:**
```
data_dir/
  speaker_001/
    chunk_000000.wav
    chunk_000001.wav
  speaker_002/
    ...
```

### Batch Training

```bash
# Run training on a long audio file
chmod +x run_beatrice.sh
./run_beatrice.sh input_folder/ output_folder/ 10000 speaker_001
```

Arguments:
- `input_folder/`: Contains the long audio file (>100MB)
- `output_folder/`: Where results and checkpoints will be saved
- `10000`: Number of training iterations
- `speaker_001`: Speaker name (optional, auto-generated if omitted)

The script will:
1. Find the large audio file in `input_folder/`
2. Split it into 4-second chunks using `chunk_audio.py`
3. Save chunks in `output_folder/chunks/speaker_001/`
4. Run Beatrice training for 10,000 iterations
5. Save checkpoints to `output_folder/checkpoints/`
6. Save logs to `output_folder/logs/`

## Requirements

- Python 3.9+
- PyTorch 2.x
- torchaudio
- soundfile
- bash

## Example

```bash
# Process a long speech file from speaker A
./run_beatrice.sh ./long_speech.wav ./results 5000 speaker_001

# Or let it auto-generate speaker name
./run_beatrice.sh ./long_speech.wav ./results 5000

# Check results
ls ./results/chunks/speaker_001/
```

The chunks are saved in 24kHz sample rate (standard for Beatrice).
If your input is stereo, it will be converted to mono.
The original file is moved to a backup folder to prevent accidental overwrites.
Training requires access to pretrained phone extractor and pitch estimator models.

- The chunks are saved in 24kHz sample rate (standard for Beatrice)
- If your input is stereo, it will be converted to mono
- The original file is moved to a backup folder to prevent accidental overwrites
- Training requires access to pretrained phone extractor and pitch estimator models
