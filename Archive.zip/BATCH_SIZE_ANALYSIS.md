# Batch Size Scaling Analysis

## Current Configuration

| Parameter | Value | Notes |
|-----------|-------|-------|
| batch_size | 8 | Hardcoded in `run_beatrice.sh` |
| wav_length | 96000 | 4 sec at 24kHz output (fixed) |
| segment_length | 100 | 1 sec discriminator window |
| learning_rate_g | 5e-5 | Generator |
| learning_rate_d | 5e-5 | Discriminator |
| warmup_steps | n_steps / 2 | Set by `run_beatrice.sh` |
| gradient accumulation | None | Each iteration = one optimizer step |

## Hardcoded Batch-Dependent Values

**None found.** All tensor operations use dynamic shapes from `x.size(0)`. The code is batch_size-agnostic for correctness.

## Memory Scaling on M4 Max MPS (Unified Memory: 36-48 GB)

| batch_size | Estimated MPS Memory | CPU Memory (pitch est.) | Feasibility |
|-----------|---------------------|------------------------|-------------|
| 8 | ~0.6 GB | ~0.3 GB | Current default, stable |
| 16 | ~1.0 GB | ~0.5 GB | Safe, recommended next step |
| 32 | ~1.6 GB | ~0.9 GB | Feasible; watch NaN |
| 64 | ~2.8 GB | ~1.5 GB | Risky; high NaN probability on MPS |

There is ample memory headroom on M4 Max. The bottleneck is **MPS numerical stability**, not memory.

## Key Memory Consumers Per Batch Element

| Tensor | Shape per sample | ~FP16 Size |
|--------|-----------------|------------|
| Full wav (clean_wavs) | [96000] | 192 KB |
| Noisy wav (16kHz) | [6400] | 12.8 KB |
| Phone features | [128, 600] | 153.6 KB |
| Pitch features | [448, 600] | 537.6 KB |
| Vocoder internal (ir_amp+phase) | [512, 100] | 102.4 KB |
| y_hat output | [1, 24000] | 48 KB |
| **Subtotal per sample** | | **~2.1 MB** |

The formant shift augmentation creates a concatenated tensor of `batch_size * ~112000` samples on MPS, then moves it to CPU for pitch estimation. This is freed within the augmentation block.

The discriminator processes `2 * batch_size` (real + generated concatenated), so its feature maps scale 2x with batch_size.

## Required Parameter Changes When Increasing batch_size

| Parameter | Rule | Rationale |
|-----------|------|-----------|
| `learning_rate_g` | Scale linearly: `LR_new = LR_base * (new_bs / 8)` | Standard linear scaling for mean-reduced losses |
| `learning_rate_d` | Same as above | Same rationale |
| `warmup_steps` | Keep at 50% of n_steps (already auto-set) | Longer warmup helps stability at higher LR |

### Learning Rate Recommendations

| batch_size | LR scaling | Suggested LR_g/d |
|-----------|-----------|-----------------|
| 8 | 1x | 5e-5 |
| 16 | 2x | 1e-4 |
| 32 | 4x | 2e-4 |
| 64 | 8x | 4e-4 |

For GANs, the linear rule can be aggressive. A more conservative sqrt scaling is also viable: `LR_new = LR_base * sqrt(new_bs / 8)`.

## Risks and Trade-offs

### 1. MPS NaN Propensity (PRIMARY RISK)

Larger batches produce larger intermediate tensors that are more likely to trigger MPS numerical issues, especially in the vocoder's FFT synthesis path. The existing NaN handling (forward skip, grad skip, CPU optimizer steps, grad clamping) mitigates this but doesn't eliminate it. At higher batch sizes, more iterations may be skipped, reducing effective training progress.

### 2. Pitch Augmentation Compute Bottleneck

The per-sample resampling loop (`for i in range(batch_size)`) is sequential — each sample is resampled individually with a fresh `torchaudio.transforms.Resample` on MPS. Doubling batch_size doubles this loop's iteration count with no GPU parallelism benefit.

### 3. CPU↔MPS Transfer Overhead

The optimizer step moves the entire model + optimizer state to CPU and back every iteration. This cost is constant regardless of batch_size, so larger batches amortize it better (good).

### 4. GAN Stability

Larger batch_size + higher LR can destabilize the generator-discriminator equilibrium. If discriminator loss collapses to 0, the generator receives no useful gradient signal. Monitor `loss_d/loss_discriminator` closely — if it consistently stays near 0, reduce LR or batch_size.

## Alternative: Gradient Accumulation (No Code Changes Yet)

Instead of increasing physical batch_size, gradient accumulation provides the same effective batch_size with no memory increase or additional NaN risk:

- E.g., 4 micro-batches of batch_size=8 with accumulation = effective batch_size 32
- Keeps per-iteration memory identical to batch_size=8
- Avoids increased NaN risk from larger tensors
- Requires code changes to `__main__.py` (accumulate grads, delay optimizer step)
- Standard pattern: run N micro-batches, sum gradients, then single optimizer step

This is the safest path for MPS if larger effective batch sizes are desired.

## Recommendations for Fine-tuning

For fine-tuning (where the model already has good weights and only needs small adjustments):

- **batch_size=16, LR=1e-4** — safe starting point, modest speed gain
- **batch_size=8, LR=2e-5** — conservative fine-tuning LR with current batch_size (reduces overfitting risk)
- **Gradient accumulation** — best approach if effective batch_size > 16 is desired on MPS
- **Monitor**: `loss_d/loss_discriminator` should oscillate around 1-3, never collapse to 0
- **Watch NaN skip rate** — if >20% iterations skipped, reduce batch_size or LR
