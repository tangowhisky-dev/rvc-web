#!/usr/bin/env python3
"""Split audio file into 4-second chunks for Beatrice trainer.

Usage:
    python chunk_audio.py input.wav output_dir speaker_name

This script:
1. Loads any audio format (wav, mp3, flac, etc.)
2. Splits into 4-second chunks (96000 samples @ 24kHz)
3. Saves chunks in a folder named after the speaker
4. Moves original file to backup location

The Beatrice trainer expects:
  data_dir/
    speaker_001/
      chunk_000000.wav
      chunk_000001.wav
    speaker_002/
      ...

So chunks are organized by speaker identity.
"""

import argparse
import os
import shutil
import sys
from pathlib import Path

import soundfile as sf
import torch
import torchaudio


def get_audio_info(path: str) -> tuple[Path, int, int, int, torch.Tensor]:
    """Get audio file info and waveform.

    Returns:
        (path, sample_rate, num_samples, num_channels, wav)
    """
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"File not found: {path}")

    try:
        wav, sr = torchaudio.load(str(path))
        return path, sr, wav.shape[1], wav.shape[0], wav
    except (RuntimeError, OSError, ValueError) as e:
        import logging
        logging.getLogger(__name__).debug(f"torchaudio.load failed for {path}: {e}, trying soundfile")
        # Fallback to soundfile
        wav_np, sr = sf.read(str(path))
        wav = torch.from_numpy(wav_np).T
        if wav.dim() == 1:
            wav = wav.unsqueeze(0)
        return path, sr, wav.shape[1], wav.shape[0], wav

def split_audio(
    input_path: str,
    output_dir: str,
    chunk_duration: float = 4.0,
    speaker_name: str = None
) -> list[Path]:
    """Split audio into chunks.
    
    Args:
        input_path: Path to input audio file
        output_dir: Directory to save chunks
        chunk_duration: Duration of each chunk in seconds (default 4.0)
        speaker_name: Name of speaker folder (e.g., "speaker_001" or None to auto-generate)
    
    Returns:
        List of chunk file paths
    """
    path, sample_rate, total_samples, num_channels, wav = get_audio_info(input_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Generate speaker folder name if not provided
    if speaker_name is None:
        # Auto-generate from filename or use default
        speaker_name = f"speaker_{path.stem.zfill(3)}"
    
    # Ensure speaker folder name matches Beatrice naming convention
    # Beatrice expects folders like "speaker_001", "speaker_002", etc.
    if not speaker_name.startswith("speaker_"):
        speaker_name = f"speaker_{speaker_name.zfill(3)}"
    
    speaker_folder = output_dir / speaker_name
    speaker_folder.mkdir(parents=True, exist_ok=True)
    
    print(f"Speaker folder: {speaker_folder}")
    print(f"Channels: {num_channels}")
    
    # Calculate chunk size in samples
    chunk_samples = int(sample_rate * chunk_duration)
    
    # Handle stereo audio by converting to mono if necessary
    if num_channels > 1:
        print(f"Converting stereo to mono (channels: {num_channels})")
        wav = wav.mean(dim=0, keepdim=True)
    
    # Split into chunks
    chunks = []
    num_chunks = (total_samples + chunk_samples - 1) // chunk_samples
    
    for i in range(num_chunks):
        start = i * chunk_samples
        end = min(start + chunk_samples, total_samples)
        
        if start >= end:
            break
        
        # Extract chunk
        chunk = wav[:, start:end]
        
        # Save chunk
        chunk_filename = speaker_folder / f"chunk_{i:06d}.wav"
        torchaudio.save(str(chunk_filename), chunk, sample_rate)
        chunks.append(chunk_filename)
    
    # Move original file outside output directory
    # backup_dir = output_dir.parent / "backup"
    # backup_dir.mkdir(exist_ok=True)
    # backup_path = backup_dir / f"original_{path.name}"
    # shutil.move(str(path), str(backup_path))
    
    return chunks


def main():
    parser = argparse.ArgumentParser(description="Split audio into 4-second chunks")
    parser.add_argument("input", type=str, help="Input audio file")
    parser.add_argument("output_dir", type=str, help="Output directory for chunks")
    parser.add_argument("speaker_name", type=str, nargs="?", default=None, help="Speaker name/folder (optional, auto-generated if omitted)")
    parser.add_argument("--chunk-duration", type=float, default=4.0, help="Chunk duration in seconds")
    args = parser.parse_args()
    
    print(f"Processing: {args.input}")
    print(f"Output directory: {args.output_dir}")
    
    chunks = split_audio(args.input, args.output_dir, args.chunk_duration, args.speaker_name)
    
    print(f"Created {len(chunks)} chunks")
    # for i, chunk in enumerate(chunks):
    #     print(f"  {i+1:3d}. {chunk.name}")


if __name__ == "__main__":
    main()
