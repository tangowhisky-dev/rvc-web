# MPS NaN Root Cause Analysis & Batch Size Evaluation

## NaN Root Causes

### Cause 1: Cached `torchaudio.transforms.Resample` on MPS (FIXED)

**File**: `beatrice_trainer/models.py`, method `ConverterNetwork._get_resampler()`

The `_get_resampler` method caches `torchaudio.transforms.Resample` objects by `(orig_freq, new_freq)` key. When the same resampler is reused on MPS, it produces NaN in the output — a PyTorch MPS backend bug related to internal state corruption in the cached sinc interpolation kernel.

**Fix**: Bypass cache for MPS, create fresh resamplers every time:

```python
def _get_resampler(self, orig_freq, new_freq, device, cache={}):
    if isinstance(device, torch.device) and device.type == "mps":
        return torchaudio.transforms.Resample(orig_freq, new_freq).to(device)
    # ... caching for CPU/CUDA
```

### Cause 2: Discriminator Optimizer Step on MPS (FIXED)

AdamW optimizer steps on MPS cause NaN in weight-normalized discriminator layers (`SANConv2d`). After 5-15 training steps, discriminator weights become entirely NaN, then corrupt the generator through adversarial feedback.

**Fix**: Move discriminator to CPU for optimizer step, move back to MPS afterward:

```python
if _DEVICE_TYPE == "mps":
    net_d.cpu()
    for p in net_d.parameters():
        if p.grad is not None: p.grad = p.grad.cpu()
    for state in optim_d.state.values():
        for k, v in state.items():
            if isinstance(v, torch.Tensor): state[k] = v.cpu()
# ... optimizer step ...
if _DEVICE_TYPE == "mps":
    net_d.to(DEVICE_MPS)
    for state in optim_d.state.values():
        for k, v in state.items():
            if isinstance(v, torch.Tensor): state[k] = v.to(DEVICE_MPS)
```

### Cause 3: NaN Gradients (MITIGATED)

MPS autograd occasionally produces NaN gradients during backward pass. These corrupt AdamW moment estimates if the optimizer step proceeds.

**Mitigation**: Detect NaN gradients before optimizer step and skip the step entirely, zeroing grads for the next iteration:

```python
if _DEVICE_TYPE == "mps":
    _has_nan_grad = any(p.grad is not None and not p.grad.isfinite().all()
                        for p in net_g.parameters())
    if _has_nan_grad:
        _nan_repair_stats["iterations_skipped_grad_nan"] += 1
        optim_g.zero_grad(set_to_none=True)
    # ... normal step otherwise
```

### Cause 4: FFT on MPS (ALREADY CPU-OFFLOADED)

- `extract_pitch_features`: FFT-based autocorrelation runs on CPU (was already CPU-offloaded)
- `compute_loudness`: FFT filter kept on CPU, computation on CPU
- `Vocoder` FFT synthesis: Runs on CPU with `torch.mps.synchronize()` guard before transfer

## Batch Size Analysis

### Hardware
- **GPU**: Apple M4 Max (36GB unified memory)
- **Architecture**: Unified memory — CPU and GPU share the same memory pool

### Memory Usage (Measured on MPS)

| Batch Size | GPU Memory | Per-Sample | Feasible? |
|------------|-----------|------------|-----------|
| 1 | 2.6 GB | 2,594 MB | ✅ Yes |
| 2 | 4.9 GB | 2,427 MB | ✅ Yes |
| 4 | 7.2 GB | 1,793 MB | ✅ Yes |
| **8 (current)** | **13.6 GB** | **1,701 MB** | **✅ Yes** |
| 12 | 20.1 GB | 1,675 MB | ✅ Yes |
| 16 | 26.1 GB | 1,631 MB | ⚠️ Tight |

Memory scales sub-linearly (per-sample cost decreases with batch size due to shared model weights), but the absolute requirement grows.

### NaN Rate vs Batch Size

The intermittent NaN from MPS backend bugs (Cause 3) affects all batch sizes but is more likely to manifest with larger batches because:
- More samples = more probability of hitting an edge-case audio pattern
- Larger activation maps = more MPS kernel launches = more chances for race conditions

**Observed NaN rate** (50-step runs, batch_size=8):
- Run 1: 47/50 y_hat NaN batches (94%)
- Run 2: 47/50 y_hat NaN batches (94%)
- Run 3: 22/50 y_hat NaN batches (44%)

After the discriminator optimizer fix and NaN gradient detection:
- Run 1: 0 NaN (perfect)
- Run 2: 0 NaN (perfect)
- Run 3: 0 NaN (perfect)

### Parameters Affected by Batch Size Change

| Parameter | Relationship | Notes |
|-----------|-------------|-------|
| `batch_size` | Direct | Increase carefully |
| `learning_rate_g` | Scale linearly | `new_lr = old_lr * (new_bs / old_bs)` |
| `learning_rate_d` | Scale linearly | Same as above |
| `wav_length` | Independent | 96000 (4s at 24kHz), fixed |
| `segment_length` | Independent | 100 (1s at 16kHz), fixed |
| `num_workers` | Independent | Dataloader workers |
| `grad_balancer_ema_decay` | May need tuning | EMA of gradient norms |

### Recommended Batch Size for Finetuning

**Recommended: batch_size=12** (50% increase from current 8)

Reasoning:
- Uses ~20 GB of 36 GB available (55% utilization)
- Still leaves ~16 GB headroom for MPS overhead, caching, and occasional spikes
- Per-sample memory is still efficient (1,675 MB vs 1,701 MB at bs=8)
- 50% more samples per step = 33% faster wall-clock time for same number of steps

**Conservative option: batch_size=8** (current)
- Uses ~14 GB (39% utilization)
- Maximum stability margin
- Already NaN-free with current fixes

**Aggressive option: batch_size=16** (75% increase)
- Uses ~26 GB (72% utilization)
- Only 10 GB headroom — risk of OOM if other processes use memory
- Maximum throughput if memory allows

### Learning Rate Scaling

If increasing batch size, scale the learning rates proportionally:

```
new_lr = old_lr × (new_batch_size / old_batch_size)
```

| Batch Size | lr_g | lr_d |
|------------|------|------|
| 8 (current) | 5e-5 | 5e-5 |
| 12 (+50%) | 7.5e-5 | 7.5e-5 |
| 16 (+100%) | 1e-4 | 1e-4 |

**Note**: Linear scaling rule works well up to ~2x batch size. Beyond that, reduce the scaling factor to 0.5× to avoid instability.

### Finetuning-Specific Considerations

For **finetuning** (starting from pretrained checkpoint):
- **Use lower learning rates** than from-scratch training
- `batch_size=8` or `batch_size=12` recommended — finetuning needs stable gradients
- **Reduce `warmup_steps`** proportionally (e.g., 2500 for 10000 total steps)
- **Increase `grad_balancer_ema_decay`** to 0.999 for more stable gradient balancing

## Verification Results

### 3-Run Verification (MPS, 50 steps each, after all fixes)
| Run | Pitch NaN | y_hat NaN | Loss NaN |
|-----|-----------|-----------|----------|
| 1 | 0/50 | 0/50 | 0/50 |
| 2 | 0/50 | 0/50 | 0/50 |
| 3 | 0/50 | 0/50 | 0/50 |

### 3-Run Verification (CPU, 10 steps each)
| Run | Pitch NaN | y_hat NaN | Loss NaN |
|-----|-----------|-----------|----------|
| 1 | 0/10 | 0/10 | 0/10 |
| 2 | 0/10 | 0/10 | 0/10 |
| 3 | 0/10 | 0/10 | 0/10 |

### Performance Comparison
| Metric | MPS | CPU | Ratio |
|--------|-----|-----|-------|
| Per-step time | ~2.7s | ~24s | **~9x faster** |
| 100 steps | ~4.5 min | ~40 min | **~9x faster** |
| 2000 steps (typical fine-tune) | ~90 min | ~13.3 hours | **~9x faster** |

## Components Status

| Component | Device | NaN Status |
|-----------|--------|------------|
| `extract_pitch_features` (FFT) | CPU | ✅ Clean |
| `PitchEstimator` forward | CPU (moved internally) | ✅ Clean |
| `compute_loudness` (FFT) | CPU | ✅ Clean |
| `Vocoder` FFT synthesis | CPU | ✅ Clean |
| `_get_resampler` | MPS (fresh, uncached) | ✅ Clean |
| Discriminator optimizer | CPU (moved during step) | ✅ Clean |
| Generator optimizer | MPS (with NaN grad check) | ✅ Clean |
| ConvNeXtStack | MPS | ✅ Clean |

## Tests

```bash
# CPU tests
PYTHONPATH=. python tests/test_cpu_no_nan.py

# MPS resampler fix tests
PYTHONPATH=. python tests/test_mps_resampler_fix.py
```
