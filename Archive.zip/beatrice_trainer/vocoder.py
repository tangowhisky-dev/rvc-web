from .d4c import overlap_add, generate_noise
from .modules import ConvNeXtStack, WSConv1d, WSLinear, dump_layer
"""Beatrice Trainer — Neural vocoder."""
import math
from pathlib import Path
from typing import BinaryIO, Union

import torch
import torch.nn as nn
import torch.nn.functional as F

from ._compat import is_notebook, repo_root, PARAPHERNALIA_VERSION

class Vocoder(nn.Module):
    def __init__(
        self,
        channels: int,
        speaker_embedding_channels: int = 128,
        hop_length: int = 240,
        n_pre_blocks: int = 4,
        out_sample_rate: float = 24000.0,
    ):
        super().__init__()
        self.hop_length = hop_length
        self.out_sample_rate = out_sample_rate

        self.prenet = ConvNeXtStack(
            in_channels=channels,
            channels=channels,
            intermediate_channels=channels * 2,
            n_blocks=n_pre_blocks,
            delay=2,  # 20ms 遅延
            embed_kernel_size=7,
            kernel_size=33,
            enable_scaling=True,
            use_mha=True,
            cross_attention=True,
            kv_channels=speaker_embedding_channels,
        )
        self.ir_generator = ConvNeXtStack(
            in_channels=channels,
            channels=channels,
            intermediate_channels=channels * 2,
            n_blocks=2,
            delay=0,
            embed_kernel_size=3,
            kernel_size=33,
            use_weight_standardization=True,
            enable_scaling=True,
        )
        self.ir_generator_post = WSConv1d(channels, 512, 1)
        self.register_buffer("ir_scale", torch.tensor(1.0))
        self.ir_window = nn.Parameter(torch.ones(512))
        self.aperiodicity_generator = ConvNeXtStack(
            in_channels=channels,
            channels=channels,
            intermediate_channels=channels * 2,
            n_blocks=1,
            delay=0,
            embed_kernel_size=3,
            kernel_size=33,
            use_weight_standardization=True,
            enable_scaling=True,
        )
        self.aperiodicity_generator_post = WSConv1d(channels, hop_length, 1, bias=False)
        self.register_buffer("aperiodicity_scale", torch.tensor(0.005))
        self.post_filter_generator = ConvNeXtStack(
            in_channels=channels,
            channels=channels,
            intermediate_channels=channels * 2,
            n_blocks=1,
            delay=0,
            embed_kernel_size=3,
            kernel_size=33,
            use_weight_standardization=True,
            enable_scaling=True,
        )
        self.post_filter_generator_post = WSConv1d(channels, 512, 1, bias=False)
        self.register_buffer("post_filter_scale", torch.tensor(0.01))

    def forward(
        self, x: torch.Tensor, pitch: torch.Tensor, speaker_embedding: torch.Tensor
    ) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        # x: [batch_size, channels, length]
        # pitch: [batch_size, length]
        # speaker_embedding: [batch_size, speaker_embedding_length, speaker_embedding_channels]
        batch_size, _, length = x.size()

        x = self.prenet(x, speaker_embedding)
        ir = self.ir_generator(x)
        ir = F.silu(ir, inplace=False)  # MPS: inplace=True can cause NaN
        # [batch_size, 512, length]
        ir = self.ir_generator_post(ir)
        ir *= self.ir_scale
        # Clamp before exp() to prevent overflow on MPS where numerical
        # differences in backward can produce extreme values.
        ir_raw = ir[:, : ir.size(1) // 2 + 1, :].clamp(max=10.0)
        ir_amp = ir_raw.exp()
        ir_phase = F.pad(ir[:, ir.size(1) // 2 + 1 :, :], (0, 0, 1, 1))
        ir_phase[:, 1::2, :] += math.pi
        # TODO: 直流成分が正の値しか取れないのを修正する

        # 最近傍補間
        # [batch_size, length * hop_length]
        pitch_up = torch.repeat_interleave(pitch, self.hop_length, dim=1)

        aperiodicity = self.aperiodicity_generator(x)
        aperiodicity = F.silu(aperiodicity, inplace=False)  # MPS: inplace=True can cause NaN
        # [batch_size, hop_length, length]
        aperiodicity = self.aperiodicity_generator_post(aperiodicity)
        aperiodicity *= self.aperiodicity_scale

        post_filter = self.post_filter_generator(x)
        post_filter = F.silu(post_filter, inplace=False)  # MPS: inplace=True can cause NaN
        # [batch_size, 512, length]
        post_filter = self.post_filter_generator_post(post_filter)
        post_filter *= self.post_filter_scale
        post_filter[:, 0, :] += 1.0

        # Move FFT synthesis to CPU to avoid MPS NaN. Gradients flow through
        # the neural network layers above; the FFT synthesis functions have no
        # trainable parameters so gradient through detach() is not needed.
        target_device = x.device
        # CRITICAL: Synchronize MPS before CPU transfer to prevent corruption
        # See: https://github.com/pytorch/pytorch/issues/117617
        if target_device.type == "mps":
            torch.mps.synchronize()
        ir_amp_cpu = ir_amp.cpu()
        ir_phase_cpu = ir_phase.cpu()
        pitch_cpu = pitch_up.cpu()
        aperiodicity_cpu = aperiodicity.cpu()
        post_filter_cpu = post_filter.cpu().transpose(1, 2)

        # [batch_size, length * hop_length]
        periodic_signal_cpu = overlap_add(
            ir_amp_cpu,
            ir_phase_cpu,
            self.ir_window.cpu(),
            pitch_cpu,
            self.hop_length,
            delay=0,
            sr=self.out_sample_rate,
        )

        # [batch_size, length * hop_length], [batch_size, length * hop_length]
        aperiodic_signal_cpu, noise_excitation_cpu = generate_noise(
            aperiodicity_cpu, delay=0
        )

        with torch.amp.autocast("cpu", enabled=False):
            periodic_signal_cpu = periodic_signal_cpu.float()
            aperiodic_signal_cpu = aperiodic_signal_cpu.float()
            post_filter_cpu = post_filter_cpu.float()
            post_filter_cpu = torch.fft.rfft(post_filter_cpu, n=768)

            # [batch_size, length, 768]
            periodic_signal_cpu = torch.fft.irfft(
                torch.fft.rfft(
                    periodic_signal_cpu.view(batch_size, length, self.hop_length), n=768
                )
                * post_filter_cpu,
                n=768,
            )
            aperiodic_signal_cpu = torch.fft.irfft(
                torch.fft.rfft(
                    aperiodic_signal_cpu.view(batch_size, length, self.hop_length), n=768
                )
                * post_filter_cpu,
                n=768,
            )
            periodic_signal_cpu = F.fold(
                periodic_signal_cpu.transpose(1, 2),
                (1, (length - 1) * self.hop_length + 768),
                (1, 768),
                stride=(1, self.hop_length),
            ).squeeze_((1, 2))
            aperiodic_signal_cpu = F.fold(
                aperiodic_signal_cpu.transpose(1, 2),
                (1, (length - 1) * self.hop_length + 768),
                (1, 768),
                stride=(1, self.hop_length),
            ).squeeze_((1, 2))
        periodic_signal_cpu = periodic_signal_cpu[:, 120 : 120 + length * self.hop_length]
        aperiodic_signal_cpu = aperiodic_signal_cpu[:, 120 : 120 + length * self.hop_length]
        noise_excitation_cpu = noise_excitation_cpu[:, 120:]

        # Transfer results back to target device
        periodic_signal = periodic_signal_cpu.to(target_device)
        aperiodic_signal = aperiodic_signal_cpu.to(target_device)
        noise_excitation = noise_excitation_cpu.to(target_device)

        # TODO: compensation の正確さが怪しくなってくる。今も本当に必要なのか？

        # [batch_size, 1, length * hop_length]
        y_g_hat = (periodic_signal + aperiodic_signal)[:, None, :]

        return y_g_hat, {
            "periodic_signal": periodic_signal.detach(),
            "aperiodic_signal": aperiodic_signal.detach(),
            "noise_excitation": noise_excitation.detach(),
        }

    def merge_weights(self):
        self.prenet.merge_weights()
        self.ir_generator.merge_weights()
        self.ir_generator_post.merge_weights()
        self.aperiodicity_generator.merge_weights()
        self.aperiodicity_generator_post.merge_weights()
        self.ir_generator_post.weight.data *= self.ir_scale
        self.ir_generator_post.bias.data *= self.ir_scale
        self.ir_scale.fill_(1.0)
        self.aperiodicity_generator_post.weight.data *= self.aperiodicity_scale
        self.aperiodicity_scale.fill_(1.0)
        self.post_filter_generator.merge_weights()
        self.post_filter_generator_post.merge_weights()
        self.post_filter_generator_post.weight.data *= self.post_filter_scale
        self.post_filter_scale.fill_(1.0)

    def dump(self, f: Union[BinaryIO, str, bytes, Path]):
        if isinstance(f, (str, bytes, Path)):
            with open(f, "wb") as f:
                self.dump(f)
            return
        if not hasattr(f, "write"):
            raise TypeError

        dump_layer(self.prenet, f)
        dump_layer(self.ir_generator, f)
        dump_layer(self.ir_generator_post, f)
        dump_layer(self.ir_window, f)
        dump_layer(self.aperiodicity_generator, f)
        dump_layer(self.aperiodicity_generator_post, f)
        dump_layer(self.post_filter_generator, f)
        dump_layer(self.post_filter_generator_post, f)


