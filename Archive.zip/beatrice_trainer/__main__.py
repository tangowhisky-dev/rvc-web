#!/usr/bin/env python3
"""Beatrice Trainer entry point."""
import math, os, sys, warnings, gc, gzip, shutil, json
from collections import defaultdict
from contextlib import nullcontext
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchaudio
from tqdm.auto import tqdm
from .extractors import PhoneExtractor
from .pitch import PitchEstimator
from .models import ConverterNetwork
from . import (
    is_notebook, repo_root, PARAPHERNALIA_VERSION,
    dict_default_hparams, ConvNeXtStack, MultiPeriodDiscriminator, d4c,
    compute_grad_norm, get_resampler, _nan_repair_stats, _DEVICE_TYPE,
)
from .training import prepare_training
from .utils import (
    get_compressed_optimizer_state_dict, get_decompressed_optimizer_state_dict,
)

warnings.filterwarnings("ignore", message=r"An output with one or more elements was resized")
warnings.filterwarnings("ignore", message=r"`torch.nn.utils.weight_norm` is deprecated")

_FLOAT_DTYPES = frozenset({torch.float32, torch.float16})

if __name__ == "__main__":
    (
        device,
        in_wav_dataset_dir,
        h,
        out_dir,
        speakers,
        test_filelist,
        training_loader,
        speaker_f0s,
        test_pitch_shifts,
        phone_extractor,
        pitch_estimator,
        net_g,
        net_d,
        optim_g,
        optim_d,
        grad_scaler,
        grad_balancer,
        resample_to_in_sample_rate,
        initial_iteration,
        scheduler_g,
        scheduler_d,
        dict_scalars,
        quality_tester,
        writer,
    ) = prepare_training()
    # Re-read _DEVICE_TYPE after prepare_training sets the global
    import beatrice_trainer as _bt
    _DEVICE_TYPE = _bt._DEVICE_TYPE

if __name__ == "__main__" and writer is not None:
    if h.compile_convnext:
        raw_convnextstack_forward = ConvNeXtStack.forward
        compiled_convnextstack_forward = torch.compile(
            ConvNeXtStack.forward, mode="reduce-overhead"
        )
    if h.compile_d4c:
        d4c = torch.compile(d4c, mode="reduce-overhead")
    if h.compile_discriminator:
        MultiPeriodDiscriminator.forward_and_compute_loss = torch.compile(
            MultiPeriodDiscriminator.forward_and_compute_loss, mode="reduce-overhead"
        )

    # 学習
    with (
        torch.profiler.profile(
            schedule=torch.profiler.schedule(wait=1500, warmup=10, active=5, repeat=1),
            on_trace_ready=torch.profiler.tensorboard_trace_handler(out_dir),
            record_shapes=True,
            with_stack=True,
            profile_memory=True,
            with_flops=True,
        )
        if h.profile
        else nullcontext()
    ) as profiler:
        data_iter = None
        for iteration in tqdm(range(initial_iteration, h.n_steps), desc="Training"):
            # === 1. データ前処理 ===
            try:
                batch = next(data_iter)
            except (StopIteration, TypeError):
                data_iter = iter(training_loader)
                batch = next(data_iter)
            # MPS backend: non_blocking=True can corrupt tensor data.
            # See: https://discuss.pytorch.org/t/different-results-and-sometimes-all-nans/211041/4
            non_blocking_transfer = device.type == "cuda"
            (
                clean_wavs,
                noisy_wavs_16k,
                slice_starts,
                speaker_ids,
                formant_shift_semitone,
            ) = map(lambda x: x.to(device, non_blocking=non_blocking_transfer), batch)

            # === MPS NaN protection ===
            # Before each iteration, snapshot the complete model state
            # (weights + optimizer state + grad scaler). If NaN is detected
            # at ANY point (forward, backward, or grad check), restore
            # the entire state and skip to the next sample. This effectively
            # erases the impact of NaN on that input.
            if _DEVICE_TYPE == "mps":
                _snapshot_g_params = {n: p.data.clone() for n, p in net_g.named_parameters()}
                _snapshot_d_params = {n: p.data.clone() for n, p in net_d.named_parameters()}
                _snapshot_optim_g_state = {
                    i: {k: v.clone() if isinstance(v, torch.Tensor) else v
                        for k, v in s.items()}
                    for i, s in optim_g.state.items()
                }
                _snapshot_optim_d_state = {
                    i: {k: v.clone() if isinstance(v, torch.Tensor) else v
                        for k, v in s.items()}
                    for i, s in optim_d.state.items()
                }
                _nan_detected = False

            # === 2. 学習 ===
            _skip_backward = False
            with torch.amp.autocast(_DEVICE_TYPE, enabled=h.use_amp):
                # === 2.1 Generator の順伝播 ===
                if h.compile_convnext:
                    ConvNeXtStack.forward = compiled_convnextstack_forward
                (
                    y,
                    y_hat,
                    y_hat_for_backward,
                    loss_loudness,
                    loss_mel,
                    loss_ap,
                    generator_stats,
                ) = net_g.forward_and_compute_loss(
                    noisy_wavs_16k[:, None, :],
                    speaker_ids,
                    formant_shift_semitone,
                    slice_start_indices=slice_starts,
                    slice_segment_length=h.segment_length,
                    y_all=clean_wavs[:, None, :],
                    enable_loss_ap=h.grad_weight_ap != 0.0,
                )
                if h.compile_convnext:
                    ConvNeXtStack.forward = raw_convnextstack_forward
                # === 2.2 Discriminator の順伝播 ===
                loss_discriminator, loss_adv, loss_fm, discriminator_stats = (
                    net_d.forward_and_compute_loss(y, y_hat)
                )

                # On MPS: check for NaN using .item() after synchronize.
                if _DEVICE_TYPE == "mps":
                    torch.mps.synchronize()
                    _loss_mel_val = loss_mel.item()
                    _loss_disc_val = loss_discriminator.item()
                    _nan_detected = not (math.isfinite(_loss_mel_val) and math.isfinite(_loss_disc_val))
                    if _nan_detected:
                        with open('/tmp/mps_nan_check.log', 'a') as _nan_f:
                            _nan_f.write(f"iter {iteration}: mel={_loss_mel_val:.4f} disc={_loss_disc_val:.4f} NaN!\n")
                else:
                    _finite_flags = torch.stack([
                        y_hat.isfinite().all(),
                        loss_loudness.isfinite().all(),
                        loss_mel.isfinite().all(),
                        loss_ap.isfinite().all(),
                        loss_discriminator.isfinite().all(),
                        loss_adv.isfinite().all(),
                        loss_fm.isfinite().all(),
                    ])
                    _skip_backward = not _finite_flags.all()

            # On MPS: if NaN detected at any point, restore complete state
            # and skip to next sample. This erases the NaN iteration entirely.
            if _DEVICE_TYPE == "mps" and _nan_detected:
                _nan_repair_stats["iterations_skipped_forward_nan"] += 1
                # Restore all model parameters
                for n, p in net_g.named_parameters():
                    p.data.copy_(_snapshot_g_params[n])
                for n, p in net_d.named_parameters():
                    p.data.copy_(_snapshot_d_params[n])
                # Restore optimizer state
                for i, s in optim_g.state.items():
                    for k, v in s.items():
                        if isinstance(v, torch.Tensor):
                            v.copy_(_snapshot_optim_g_state[i][k])
                for i, s in optim_d.state.items():
                    for k, v in s.items():
                        if isinstance(v, torch.Tensor):
                            v.copy_(_snapshot_optim_d_state[i][k])
                # Restore grad scaler (no-op on MPS since it's disabled)
                grad_scaler.update()
                # Zero out any stale grads
                optim_g.zero_grad(set_to_none=True)
                optim_d.zero_grad(set_to_none=True)
                # Set logged values to NaN (iteration was skipped)
                gradient_balancer_stats = {}
                grad_norm_d = math.nan
                d_grad_norm_stats = {}
                grad_norm_g = math.nan
                g_grad_norm_stats = {}
                loss_discriminator_item = float('nan')
                loss_loudness = float('nan')
                loss_mel = float('nan')
                loss_adv = float('nan')
                loss_fm = float('nan')

            # Non-MPS NaN tracking
            if _DEVICE_TYPE != "mps" and _skip_backward:
                if not _finite_flags[0]:
                    _nan_repair_stats["y_hat_nan_batches"] += 1
                if not _finite_flags[1]:
                    _nan_repair_stats["loss_nan_batches"]["loudness"] += 1
                if not _finite_flags[2]:
                    _nan_repair_stats["loss_nan_batches"]["mel"] += 1
                if not _finite_flags[3]:
                    _nan_repair_stats["loss_nan_batches"]["ap"] += 1
                if not _finite_flags[4]:
                    _nan_repair_stats["loss_nan_batches"]["disc"] += 1
                if not _finite_flags[5]:
                    _nan_repair_stats["loss_nan_batches"]["adv"] += 1
                if not _finite_flags[6]:
                    _nan_repair_stats["loss_nan_batches"]["fm"] += 1

            # === 2.3-2.5 Backward and optimizer ===
            # Only run if no NaN was detected (MPS or non-MPS)
            if not (_DEVICE_TYPE == "mps" and _nan_detected) and not _skip_backward:
                if _DEVICE_TYPE == "mps":
                    # Re-run discriminator with detached inputs to avoid
                    # retain_graph MPS autograd bug
                    loss_discriminator_det, _, _, _ = net_d.forward_and_compute_loss(
                        y.detach(), y_hat.detach()
                    )
                    loss_discriminator_det.backward()
                    loss_discriminator_item = loss_discriminator.item()
                else:
                    grad_scaler.scale(loss_discriminator).backward(
                        retain_graph=True, inputs=list(net_d.parameters())
                    )
                    loss_discriminator_item = loss_discriminator.item()
                    grad_scaler.unscale_(optim_d)
                if iteration % 5 == 0:
                    grad_norm_d, d_grad_norm_stats = compute_grad_norm(net_d, True)
                else:
                    grad_norm_d = math.nan
                    d_grad_norm_stats = {}

                # === 2.4 Generator の逆伝播 ===
                for param in net_g.parameters():
                    assert param.grad is None
                gradient_balancer_stats = grad_balancer.backward(
                    {
                        "loss_loudness": loss_loudness,
                        "loss_mel": loss_mel,
                        "loss_adv": loss_adv,
                        "loss_fm": loss_fm,
                    }
                    | ({"loss_ap": loss_ap} if h.grad_weight_ap else {}),
                    y_hat_for_backward,
                    grad_scaler,
                    skip_update_ema=iteration > 10 and iteration % 5 != 0,
                )
                loss_loudness = loss_loudness.item()
                loss_mel = loss_mel.item()
                loss_adv = loss_adv.item()
                loss_fm = loss_fm.item()
                if h.grad_weight_ap:
                    loss_ap = loss_ap.item()

                # MPS: secondary NaN check after backward (NaN can appear
                # during backward even if forward was clean). If NaN found,
                # restore the complete state from the pre-iteration snapshot.
                if _DEVICE_TYPE == "mps":
                    _nan_after_backward = (
                        not math.isfinite(loss_mel)
                        or not math.isfinite(loss_adv)
                        or not math.isfinite(loss_fm)
                    )
                    if _nan_after_backward:
                        _nan_detected = True
                        _nan_repair_stats["iterations_skipped_grad_nan"] += 1
                        with open('/tmp/mps_nan_check.log', 'a') as _nan_f:
                            _nan_f.write(f"iter {iteration}: NaN after backward, restoring snapshot\n")
                        for n, p in net_g.named_parameters():
                            p.data.copy_(_snapshot_g_params[n])
                        for n, p in net_d.named_parameters():
                            p.data.copy_(_snapshot_d_params[n])
                        for i, s in optim_g.state.items():
                            for k, v in s.items():
                                if isinstance(v, torch.Tensor):
                                    v.copy_(_snapshot_optim_g_state[i][k])
                        for i, s in optim_d.state.items():
                            for k, v in s.items():
                                if isinstance(v, torch.Tensor):
                                    v.copy_(_snapshot_optim_d_state[i][k])
                        optim_g.zero_grad(set_to_none=True)
                        optim_d.zero_grad(set_to_none=True)
                        gradient_balancer_stats = {}
                        grad_norm_d = math.nan
                        d_grad_norm_stats = {}
                        grad_norm_g = math.nan
                        g_grad_norm_stats = {}

                grad_scaler.unscale_(optim_g)
                if iteration % 5 == 0:
                    grad_norm_g, g_grad_norm_stats = compute_grad_norm(net_g, True)
                else:
                    grad_norm_g = math.nan
                    g_grad_norm_stats = {}

                # === 2.5 パラメータの更新 ===
                if _DEVICE_TYPE == "mps":
                    _DEVICE_MPS = torch.device("mps")
                    torch.mps.synchronize()
                    _has_nan_grad = any(
                        p.grad is not None and not p.grad.detach().cpu().isfinite().all()
                        for p in list(net_g.parameters()) + list(net_d.parameters())
                    )
                    if _has_nan_grad:
                        _nan_repair_stats["iterations_skipped_grad_nan"] += 1
                        _nan_detected = True
                        with open('/tmp/mps_nan_check.log', 'a') as _nan_f:
                            _nan_f.write(f"iter {iteration}: NaN grads, restoring snapshot\n")
                        # Restore complete state from snapshot
                        for n, p in net_g.named_parameters():
                            p.data.copy_(_snapshot_g_params[n])
                        for n, p in net_d.named_parameters():
                            p.data.copy_(_snapshot_d_params[n])
                        for i, s in optim_g.state.items():
                            for k, v in s.items():
                                if isinstance(v, torch.Tensor):
                                    v.copy_(_snapshot_optim_g_state[i][k])
                        for i, s in optim_d.state.items():
                            for k, v in s.items():
                                if isinstance(v, torch.Tensor):
                                    v.copy_(_snapshot_optim_d_state[i][k])
                        optim_g.zero_grad(set_to_none=True)
                        optim_d.zero_grad(set_to_none=True)
                    else:
                        _GRAD_CLAMP = 1000.0
                        for p in net_g.parameters():
                            if p.grad is not None:
                                p.grad.clamp_(-_GRAD_CLAMP, _GRAD_CLAMP)
                        for p in net_d.parameters():
                            if p.grad is not None:
                                p.grad.clamp_(-_GRAD_CLAMP, _GRAD_CLAMP)
                        # Move to CPU for optimizer step
                        net_g.cpu()
                        for p in net_g.parameters():
                            if p.grad is not None:
                                p.grad = p.grad.cpu()
                        for state in optim_g.state.values():
                            for k, v in state.items():
                                if isinstance(v, torch.Tensor):
                                    state[k] = v.cpu()
                        net_d.cpu()
                        for p in net_d.parameters():
                            if p.grad is not None:
                                p.grad = p.grad.cpu()
                        for state in optim_d.state.values():
                            for k, v in state.items():
                                if isinstance(v, torch.Tensor):
                                    state[k] = v.cpu()
                        grad_scaler.step(optim_g)
                        optim_g.zero_grad(set_to_none=True)
                        grad_scaler.step(optim_d)
                        optim_d.zero_grad(set_to_none=True)
                        grad_scaler.update()
                        # Move back to MPS
                        net_g.to(_DEVICE_MPS)
                        for state in optim_g.state.values():
                            for k, v in state.items():
                                if isinstance(v, torch.Tensor):
                                    state[k] = v.to(_DEVICE_MPS)
                        net_d.to(_DEVICE_MPS)
                        for state in optim_d.state.values():
                            for k, v in state.items():
                                if isinstance(v, torch.Tensor):
                                    state[k] = v.to(_DEVICE_MPS)
                else:
                    grad_scaler.step(optim_g)
                    optim_g.zero_grad(set_to_none=True)
                    grad_scaler.step(optim_d)
                    optim_d.zero_grad(set_to_none=True)
                    grad_scaler.update()

            # Periodically clean up MPS GPU memory to prevent driver crashes
            if _DEVICE_TYPE == "mps" and (iteration + 1) % 10 == 0:
                torch.mps.empty_cache()
                gc.collect()

            # === 3. ログ ===
            dict_scalars["loss_g/loss_loudness"].append(loss_loudness)
            dict_scalars["loss_g/loss_mel"].append(loss_mel)
            if h.grad_weight_ap:
                dict_scalars["loss_g/loss_ap"].append(loss_ap)
            dict_scalars["loss_g/loss_fm"].append(loss_fm)
            dict_scalars["loss_g/loss_adv"].append(loss_adv)
            dict_scalars["other/grad_scale"].append(grad_scaler.get_scale())
            dict_scalars["loss_d/loss_discriminator"].append(loss_discriminator_item)
            if math.isfinite(grad_norm_d):
                dict_scalars["other/gradient_norm_d"].append(grad_norm_d)
                for name, value in d_grad_norm_stats.items():
                    dict_scalars[f"~gradient_norm_d/{name}"].append(value)
            if math.isfinite(grad_norm_g):
                dict_scalars["other/gradient_norm_g"].append(grad_norm_g)
                for name, value in g_grad_norm_stats.items():
                    dict_scalars[f"~gradient_norm_g/{name}"].append(value)
            dict_scalars["other/lr_g"].append(scheduler_g.get_last_lr()[0])
            dict_scalars["other/lr_d"].append(scheduler_d.get_last_lr()[0])
            for k, v in generator_stats.items():
                dict_scalars[f"~loss_generator/{k}"].append(v)
            for k, v in discriminator_stats.items():
                dict_scalars[f"~loss_discriminator/{k}"].append(v)
            for k, v in gradient_balancer_stats.items():
                dict_scalars[f"~gradient_balancer/{k}"].append(v)

            if (iteration + 1) % 10 == 0 or iteration == 0:
                for name, scalars in dict_scalars.items():
                    if scalars:
                        writer.add_scalar(
                            name, sum(scalars) / len(scalars), iteration + 1
                        )
                        scalars.clear()
                # Log weight histograms every 10 iterations (MPS-safe)
                if _DEVICE_TYPE == "mps":
                    net_g.cpu()
                try:
                    for name, param in net_g.named_parameters():
                        p_cpu = param.detach().cpu().float()
                        if p_cpu.numel() > 0:
                            writer.add_histogram(
                                f"weight/{name}", p_cpu, iteration + 1
                            )
                except (ValueError, RuntimeError):
                    pass  # Skip histogram if tensorboard fails
                if _DEVICE_TYPE == "mps":
                    net_g.to(_DEVICE_MPS)

                intermediate_feature_stats = {}
                hook_handles = []

                def get_layer_hook(name):
                    def compute_stats(module, x, suffix):
                        if not isinstance(x, torch.Tensor):
                            return
                        if x.dtype not in _FLOAT_DTYPES:
                            return
                        if isinstance(module, nn.Identity):
                            return
                        x = x.detach().float()
                        var = x.var().item()
                        if isinstance(module, (nn.Linear, nn.LayerNorm)):
                            channel_var, channel_mean = torch.var_mean(
                                x.reshape(-1, x.size(-1)), 0
                            )
                        elif isinstance(module, nn.Conv1d):
                            channel_var, channel_mean = torch.var_mean(x, [0, 2])
                        else:
                            return
                        average_squared_channel_mean = (
                            channel_mean.square().mean().item()
                        )
                        average_channel_var = channel_var.mean().item()

                        tensor_idx = len(intermediate_feature_stats) // 3
                        intermediate_feature_stats[
                            f"var/{tensor_idx:02d}_{name}/{suffix}"
                        ] = var
                        intermediate_feature_stats[
                            f"avg_sq_ch_mean/{tensor_idx:02d}_{name}/{suffix}"
                        ] = average_squared_channel_mean
                        intermediate_feature_stats[
                            f"avg_ch_var/{tensor_idx:02d}_{name}/{suffix}"
                        ] = average_channel_var

                    def forward_pre_hook(module, input):
                        for i, input_i in enumerate(input):
                            compute_stats(module, input_i, f"input_{i}")

                    def forward_hook(module, input, output):
                        if isinstance(output, tuple):
                            for i, output_i in enumerate(output):
                                compute_stats(module, output_i, f"output_{i}")
                        else:
                            compute_stats(module, output, "output")

                    return forward_pre_hook, forward_hook

                for name, layer in net_g.named_modules():
                    forward_pre_hook, forward_hook = get_layer_hook(name)
                    hook_handles.append(
                        layer.register_forward_pre_hook(forward_pre_hook)
                    )
                    hook_handles.append(layer.register_forward_hook(forward_hook))
                try:
                    with torch.no_grad(), torch.amp.autocast(_DEVICE_TYPE, enabled=h.use_amp):
                        net_g.forward_and_compute_loss(
                            noisy_wavs_16k[:, None, :],
                            speaker_ids,
                            formant_shift_semitone,
                            slice_start_indices=slice_starts,
                            slice_segment_length=h.segment_length,
                            y_all=clean_wavs[:, None, :],
                            enable_loss_ap=h.grad_weight_ap != 0.0,
                        )
                finally:
                    for handle in hook_handles:
                        handle.remove()
                for name, value in intermediate_feature_stats.items():
                    writer.add_scalar(
                        f"~intermediate_feature_{name}", value, iteration + 1
                    )

            # === 4. 検証 ===
            if (iteration + 1) % h.evaluation_interval == 0 or iteration + 1 in {
                1,
                h.n_steps,
            }:
                if device.type == "cuda":
                    torch.backends.cudnn.benchmark = False
                    torch.cuda.empty_cache()
                net_g.eval()

                dict_qualities_all = defaultdict(list)
                n_added_wavs = 0
                with torch.inference_mode():
                    for i, ((file, target_ids), pitch_shift_semitones) in enumerate(
                        zip(test_filelist, test_pitch_shifts)
                    ):
                        source_wav, sr = torchaudio.load(file)
                        source_wav = source_wav.to(device)
                        if sr != h.in_sample_rate:
                            source_wav = get_resampler(sr, h.in_sample_rate, device)(
                                source_wav
                            )
                        original_source_wav_length = source_wav.size(1)
                        # 長さのパターンを減らしてキャッシュを効かせる
                        if source_wav.size(1) % h.in_sample_rate == 0:
                            padded_source_wav = source_wav
                        else:
                            padded_source_wav = F.pad(
                                source_wav,
                                (
                                    0,
                                    h.in_sample_rate
                                    - source_wav.size(1) % h.in_sample_rate,
                                ),
                            )
                        converted = net_g(
                            padded_source_wav[[0] * len(target_ids), None],
                            torch.tensor(target_ids, device=device),
                            torch.tensor(
                                [0.0] * len(target_ids), device=device
                            ),  # フォルマントシフト
                            torch.tensor(
                                [float(p) for p in pitch_shift_semitones], device=device
                            ),
                        ).squeeze_(1)[:, : original_source_wav_length // 160 * 240]
                        # Ensure audio is finite before TensorBoard logging
                        if not converted.isfinite().all():
                            converted = converted.nan_to_num(nan=0.0, posinf=1e-3, neginf=-1e-3)
                        # Normalize audio to [-1, 1] for TensorBoard (prevents clipping warnings)
                        _max_val = converted.abs().max()
                        if _max_val > 1.0:
                            converted = converted / _max_val
                        if i < 12:
                            if iteration == 0:
                                # Also normalize source for consistency
                                source_log = source_wav
                                _max_val = source_log.abs().max()
                                if _max_val > 1.0:
                                    source_log = source_log / _max_val
                                writer.add_audio(
                                    f"source/y_{i:02d}",
                                    source_log,
                                    iteration + 1,
                                    h.in_sample_rate,
                                )
                            for d in range(
                                min(
                                    len(target_ids),
                                    1 + (12 - i - 1) // len(test_filelist),
                                )
                            ):
                                idx_in_batch = n_added_wavs % len(target_ids)
                                writer.add_audio(
                                    f"converted/y_hat_{i:02d}_{target_ids[idx_in_batch]:03d}_{pitch_shift_semitones[idx_in_batch]:+02d}",
                                    converted[idx_in_batch],
                                    iteration + 1,
                                    h.out_sample_rate,
                                )
                                n_added_wavs += 1
                        converted = resample_to_in_sample_rate(converted)
                        quality = quality_tester.test(converted, source_wav)
                        for metric_name, values in quality.items():
                            dict_qualities_all[metric_name].extend(values)
                assert n_added_wavs == min(
                    12, len(test_filelist) * len(test_filelist[0][1])
                ), (
                    n_added_wavs,
                    len(test_filelist),
                    len(speakers),
                    len(test_filelist[0][1]),
                )
                dict_qualities = {
                    metric_name: sum(values) / len(values)
                    for metric_name, values in dict_qualities_all.items()
                    if len(values)
                }
                for metric_name, value in dict_qualities.items():
                    writer.add_scalar(f"validation/{metric_name}", value, iteration + 1)
                for metric_name, values in dict_qualities_all.items():
                    for i, value in enumerate(values):
                        writer.add_scalar(
                            f"~validation_{metric_name}/{i:03d}", value, iteration + 1
                        )
                del dict_qualities, dict_qualities_all

                net_g.train()
                if device.type == "cuda":
                    torch.backends.cudnn.benchmark = True
                    torch.cuda.empty_cache()
                gc.collect()

            # === 5. 保存 ===
            if (iteration + 1) % h.save_interval == 0 or iteration + 1 in {
                1,
                h.n_steps,
            }:
                # チェックポイント
                name = f"{in_wav_dataset_dir.name}_{iteration + 1:08d}"
                checkpoint_file_save = out_dir / f"checkpoint_{name}.pt.gz"
                if checkpoint_file_save.exists():
                    checkpoint_file_save = checkpoint_file_save.with_name(
                        f"{checkpoint_file_save.name}_{hash(None):x}"
                    )
                with gzip.open(checkpoint_file_save, "wb") as f:
                    torch.save(
                        {
                            "iteration": iteration + 1,
                            "net_g": net_g.state_dict(),
                            "phone_extractor": phone_extractor.state_dict(),
                            "pitch_estimator": pitch_estimator.state_dict(),
                            "net_d": {
                                k: v.half() for k, v in net_d.state_dict().items()
                            },
                            "optim_g": get_compressed_optimizer_state_dict(optim_g),
                            "optim_d": get_compressed_optimizer_state_dict(optim_d),
                            "grad_balancer": grad_balancer.state_dict(),
                            "grad_scaler": grad_scaler.state_dict(),
                            "h": dict(h),
                        },
                        f,
                    )
                # Atomic write to prevent corrupt checkpoints on crash
                _latest_path = out_dir / "checkpoint_latest.pt.gz"
                _tmp_path = _latest_path.with_suffix(".pt.gz.tmp")
                shutil.copy(checkpoint_file_save, _tmp_path)
                _tmp_path.rename(_latest_path)  # atomic on POSIX

                # 推論用
                paraphernalia_dir = out_dir / f"paraphernalia_{name}"
                if paraphernalia_dir.exists():
                    paraphernalia_dir = paraphernalia_dir.with_name(
                        f"{paraphernalia_dir.name}_{hash(None):x}"
                    )
                paraphernalia_dir.mkdir()
                phone_extractor_fp16 = PhoneExtractor()
                phone_extractor_fp16.load_state_dict(phone_extractor.state_dict())
                phone_extractor_fp16.remove_weight_norm()
                phone_extractor_fp16.merge_weights()
                phone_extractor_fp16.half()
                phone_extractor_fp16.dump(paraphernalia_dir / "phone_extractor.bin")
                del phone_extractor_fp16
                pitch_estimator_fp16 = PitchEstimator()
                pitch_estimator_fp16.load_state_dict(pitch_estimator.state_dict())
                pitch_estimator_fp16.merge_weights()
                pitch_estimator_fp16.half()
                pitch_estimator_fp16.dump(paraphernalia_dir / "pitch_estimator.bin")
                del pitch_estimator_fp16
                net_g_fp16 = ConverterNetwork(
                    nn.Module(),
                    nn.Module(),
                    len(speakers),
                    h.pitch_bins,
                    h.hidden_channels,
                    h.vq_topk,
                    h.training_time_vq,
                    h.phone_noise_ratio,
                    h.floor_noise_level,
                )
                net_g_fp16.load_state_dict(net_g.state_dict())
                net_g_fp16.merge_weights()
                net_g_fp16.half()
                net_g_fp16.dump(paraphernalia_dir / "waveform_generator.bin")
                net_g_fp16.dump_speaker_embeddings(
                    paraphernalia_dir / "speaker_embeddings.bin"
                )
                net_g_fp16.dump_embedding_setter(
                    paraphernalia_dir / "embedding_setter.bin"
                )
                del net_g_fp16
                shutil.copy(
                    repo_root() / "assets/images/noimage.png", paraphernalia_dir
                )
                with open(
                    paraphernalia_dir / f"beatrice_paraphernalia_{name}.toml",
                    "w",
                    encoding="utf-8",
                ) as f:
                    f.write(
                        f'''[model]
version = "{PARAPHERNALIA_VERSION}"
name = "{name}"
description = """
No description for this model.
このモデルの説明はありません。
"""
'''
                    )
                    for speaker_id, (speaker, speaker_f0) in enumerate(
                        zip(speakers, speaker_f0s)
                    ):
                        average_pitch = 69.0 + 12.0 * math.log2(speaker_f0 / 440.0)
                        average_pitch = round(average_pitch * 8.0) / 8.0
                        f.write(
                            f'''
[voice.{speaker_id}]
name = "{speaker}"
description = """
No description for this voice.
この声の説明はありません。
"""
average_pitch = {average_pitch}

[voice.{speaker_id}.portrait]
path = "noimage.png"
description = """
"""
'''
                        )
                del paraphernalia_dir

            # TODO: phone_extractor, pitch_estimator が既知のモデルであれば dump を省略

            # === 6. スケジューラ更新 ===
            scheduler_g.step()
            scheduler_d.step()
            if h.profile:
                profiler.step()

    print("Training finished.")

    # Print NaN repair diagnostics
    stats = _nan_repair_stats
    skipped_forward = stats["iterations_skipped_forward_nan"]
    skipped_grad = stats["iterations_skipped_grad_nan"]
    total_skipped = skipped_forward + skipped_grad
    total_nan_repaired = (
        stats["pitch_features_nan_elements"]
        + stats["y_hat_nan_elements"]
        + sum(stats["loss_nan_batches"].values())
    )
    any_repair = total_nan_repaired > 0 or total_skipped > 0
    print("\n" + "=" * 70)
    print("Training Diagnostics")
    print("=" * 70)
    print(f"  Pitch features NaN:")
    print(f"    Batches affected:      {stats['pitch_features_nan_batches']:>6d}")
    print(f"    Elements NaN:          {stats['pitch_features_nan_elements']:>10,}")
    print(f"  Vocoder output (y_hat) NaN:")
    print(f"    Batches affected:      {stats['y_hat_nan_batches']:>6d}")
    print(f"    Elements NaN:          {stats['y_hat_nan_elements']:>10,}")
    print(f"  Loss value NaN:")
    for loss_name, count in stats["loss_nan_batches"].items():
        print(f"    {loss_name:20s}: {count:>6d} batches")
    print(f"  Iterations skipped (no weight update):")
    print(f"    Forward NaN skip:      {skipped_forward:>6d} / {h.n_steps}")
    if _DEVICE_TYPE == "mps":
        print(f"    Grad NaN skip:         {skipped_grad:>6d} / {h.n_steps}")
    print(f"    Total skipped:         {total_skipped:>6d} / {h.n_steps}  ({100 * total_skipped / max(h.n_steps, 1):.1f}%)")
    print(f"    Effective iterations:  {h.n_steps - total_skipped:>6d} / {h.n_steps}")
    print(f"    Weight rollbacks:      {stats['weight_rollbacks']:>6d} (weights restored to last good state)")
    print("=" * 70)
    if any_repair:
        print("Note: On MPS, NaN values can appear intermittently in the forward pass.")
        print("  When NaN is detected, the backward pass and optimizer step are skipped")
        print("  for that iteration to prevent weight corruption. Skipped iterations")
        print("  still count toward the total iteration count but make no progress.")
        if _DEVICE_TYPE == "mps":
            print("  If NaN count is high, consider reducing batch_size or learning_rate,")
            print("  or using CPU (BEATRICE_DEVICE=cpu) for more stable training.")
    print()
