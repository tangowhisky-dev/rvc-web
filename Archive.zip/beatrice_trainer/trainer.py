"""Training logic and main training loop.

Contains training utilities, optimizer handling, and the main training function.
"""

import gc
import math
import os
import warnings
from collections import defaultdict
from contextlib import nullcontext
from copy import deepcopy
from pathlib import Path
from typing import Optional, Union, Literal

import torch
import torch.nn as nn
from torch.utils.tensorboard import SummaryWriter
from tqdm.auto import tqdm

from .models import (
    ConvNeXtBlock,
    ConvNeXtStack,
    CrossAttention,
    CausalConv1d,
    WSConv1d,
    WSLinear,
    dump_layer,
    dump_params,
)
from .extractor import (
    PitchEstimator,
    PhoneExtractor,
    extract_pitch_features,
)
from .dataset import convolve
from .dataset import (
    WavDataset,
    augment_audio,
    convolve,
    get_butterworth_lpf,
    get_noise,
    get_resampler,
    random_filter,
    random_formant_shift,
)


_DEVICE_TYPE = "cuda"


def compute_loudness(
    x: torch.Tensor,
    sr: int,
    win_lengths: list[int],
) -> list[torch.Tensor]:
    """Compute loudness features."""
    assert x.ndim == 2
    n_fft = 2048
    chunk_length = n_fft // 2
    n_taps = chunk_length + 1
    
    results = []
    with torch.amp.autocast(_DEVICE_TYPE, enabled=False):
        if not hasattr(compute_loudness, "filter"):
            compute_loudness.filter = {}
        if sr not in compute_loudness.filter:
            ir = torch.zeros(n_taps, device=x.device, dtype=torch.double)
            ir[0] = 0.5
            ir = torchaudio.functional.treble_biquad(
                ir, sr, 4.0, 1500.0, 1.0 / math.sqrt(2)
            )
            ir = torchaudio.functional.highpass_biquad(ir, sr, 38.0, 0.5)
            ir *= 2.0
            compute_loudness.filter[sr] = torch.fft.rfft(ir, n=n_fft).to(
                torch.complex64
            )
        
        x = x.float()
        wav_length = x.size(-1)
        if wav_length % chunk_length != 0:
            x = F.pad(x, (0, chunk_length - wav_length % chunk_length))
        padded_wav_length = x.size(-1)
        x = x.view(x.size()[:-1] + (padded_wav_length // chunk_length, chunk_length))
        x = torch.fft.irfft(
            torch.fft.rfft(x, n=n_fft) * compute_loudness.filter[sr],
            n=n_fft,
        )
        x = F.fold(
            x.transpose(-2, -1),
            (1, padded_wav_length + chunk_length),
            (1, n_fft),
            stride=(1, chunk_length),
        ).squeeze_((-3, -2))[..., :wav_length]
        
        x.square_()
        for win_length in win_lengths:
            hop_length = win_length // 4
            energy = (
                x.unfold(-1, win_length, hop_length)
                .matmul(torch.hann_window(win_length, device=x.device))
                .add_(win_length / 4.0 * 1e-5)
                .log10_()
            )
            results.append(energy)
    return results


def slice_segments(
    x: torch.Tensor,
    start_indices: torch.Tensor,
    segment_length: int,
) -> torch.Tensor:
    """Slice segments from audio."""
    batch_size, channels, _ = x.size()
    indices = start_indices[:, None, None] + torch.arange(
        segment_length, device=start_indices.device
    )
    indices = indices.expand(batch_size, channels, segment_length)
    return x.gather(2, indices)


def d4c(
    x: torch.Tensor,
    f0: torch.Tensor,
    t: torch.Tensor,
    sr: int,
    threshold: float = 0.85,
    n_fft_spec: Optional[int] = None,
    coarse_only: bool = False,
) -> tuple[torch.Tensor, torch.Tensor]:
    """D4C algorithm for aperiodicity estimation."""
    FLOOR_F0 = 71
    FLOOR_F0_D4C = 47
    UPPER_LIMIT = 15000
    FREQ_INTERVAL = 3000
    
    assert sr == int(sr)
    sr = int(sr)
    assert sr % 2 == 0
    x = torch.as_tensor(x)
    f0 = torch.as_tensor(f0)
    temporal_positions = torch.as_tensor(t)
    
    n_fft_d4c = 1 << (4 * sr // FLOOR_F0_D4C).bit_length()
    if n_fft_spec is None:
        n_fft_spec = 1 << (3 * sr // FLOOR_F0).bit_length()
    n_aperiodicities = min(UPPER_LIMIT, sr // 2 - FREQ_INTERVAL) // FREQ_INTERVAL
    assert n_aperiodicities >= 1
    window_length = FREQ_INTERVAL * n_fft_d4c // sr * 2 + 1
    window = nuttall(window_length, device=x.device)
    freq_axis = torch.arange(n_fft_spec // 2 + 1, device=x.device) * (sr / n_fft_spec)
    
    coarse_aperiodicity, rms = d4c_general_body(
        x[..., None, :],
        sr,
        f0.clamp(min=FLOOR_F0_D4C),
        FREQ_INTERVAL,
        temporal_positions,
        n_fft_d4c,
        n_aperiodicities,
        window,
    )
    if coarse_only:
        return coarse_aperiodicity, rms
    
    even_coarse_axis = (
        torch.arange(n_aperiodicities + 3, device=x.device) * FREQ_INTERVAL
    )
    assert even_coarse_axis[-2] <= sr // 2 < even_coarse_axis[-1], sr
    coarse_axis_low = (
        torch.arange(n_aperiodicities + 1, dtype=torch.float, device=x.device)
        * FREQ_INTERVAL
    )
    aperiodicity_low = interp(
        coarse_axis_low,
        F.pad(coarse_aperiodicity, (1, 0), value=-60.0),
        freq_axis[freq_axis < n_aperiodicities * FREQ_INTERVAL],
    )
    coarse_axis_high = torch.tensor(
        [n_aperiodicities * FREQ_INTERVAL, sr * 0.5], device=x.device
    )
    aperiodicity_high = interp(
        coarse_axis_high,
        F.pad(coarse_aperiodicity[..., -1:], (0, 1), value=-1e-12),
        freq_axis[freq_axis >= n_aperiodicities * FREQ_INTERVAL],
    )
    aperiodicity = torch.cat([aperiodicity_low, aperiodicity_high], -1)
    aperiodicity = 10.0 ** (aperiodicity / 20.0)
    vuv = d4c_love_train(x[..., None, :], sr, f0, temporal_positions, threshold)
    aperiodicity = torch.where(vuv[..., None], aperiodicity, 1 - 1e-12)
    
    return aperiodicity, coarse_aperiodicity


def interp(x: torch.Tensor, y: torch.Tensor, xi: torch.Tensor) -> torch.Tensor:
    """Linear interpolation."""
    x = torch.as_tensor(x)
    y = torch.as_tensor(y)
    xi = torch.as_tensor(xi)
    if xi.ndim < y.ndim:
        diff_ndim = y.ndim - xi.ndim
        xi = xi.view(tuple([1] * diff_ndim) + xi.size())
    if xi.size()[:-1] != y.size()[:-1]:
        xi = xi.expand(y.size()[:-1] + (xi.size(-1),))
    assert (x.min(-1).values == x[..., 0]).all()
    assert (x.max(-1).values == x[..., -1]).all()
    assert (xi.min(-1).values >= x[..., 0]).all()
    assert (xi.max(-1).values <= x[..., -1]).all()
    delta_x = (x[..., -1].double() - x[..., 0].double()) / (x.size(-1) - 1.0)
    delta_x = delta_x.to(x.dtype)
    xi = (xi - x[..., :1]).div_(delta_x[..., None])
    xi_base = xi.floor()
    xi_fraction = xi.sub_(xi_base)
    xi_base = xi_base.long()
    delta_y = y.diff(dim=-1, append=y[..., -1:])
    yi = y.gather(-1, xi_base) + delta_y.gather(-1, xi_base) * xi_fraction
    return yi


def nuttall(n: int, device: torch.types.Device) -> torch.Tensor:
    """Nuttall window."""
    t = torch.linspace(0, math.tau, n, device=device)
    coefs = torch.tensor([0.355768, -0.487396, 0.144232, -0.012604], device=device)
    terms = torch.tensor([0.0, 1.0, 2.0, 3.0], device=device)
    cos_matrix = (terms[:, None] * t).cos_()
    window = coefs.matmul(cos_matrix)
    return window


def get_static_centroid(
    x: torch.Tensor,
    sr: int,
    f0: torch.Tensor,
    position: torch.Tensor,
    n_fft: int,
) -> torch.Tensor:
    """Get static centroid for D4C."""
    x1, _ = get_windowed_waveform(
        x, sr, f0, position + 0.25 / f0, 2.0, "blackman", n_fft
    )
    x2, _ = get_windowed_waveform(
        x, sr, f0, position - 0.25 / f0, 2.0, "blackman", n_fft
    )
    centroid1 = get_centroid(x1, n_fft)
    centroid2 = get_centroid(x2, n_fft)
    return dc_correction(centroid1 + centroid2, sr, n_fft, f0)


def get_windowed_waveform(
    x: torch.Tensor,
    sr: int,
    f0: torch.Tensor,
    position: torch.Tensor,
    half_window_length_ratio: float,
    window_type: str,
    n_fft: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Get windowed waveform for D4C."""
    x = torch.as_tensor(x)
    f0 = torch.as_tensor(f0)
    position = torch.as_tensor(position)
    
    current_sample = position * sr
    half_window_length = (half_window_length_ratio * sr / f0).add_(0.5).long()
    base_index = -half_window_length[..., None] + torch.arange(n_fft, device=x.device)
    base_index_mask = base_index <= half_window_length[..., None]
    safe_index = ((current_sample + 0.501).long()[..., None] + base_index).clamp(
        0, x.size(-1) - 1
    )
    time_axis = base_index.to(x.dtype).div_(half_window_length_ratio)
    normalized_f0 = math.pi / sr * f0
    phase = time_axis.mul_(normalized_f0[..., None])
    
    if window_type == "hann":
        window = phase.cos_().mul_(0.5).add_(0.5)
    elif window_type == "blackman":
        window = phase.mul(2.0).cos_().mul_(0.08).add_(phase.cos().mul_(0.5)).add_(0.42)
    else:
        assert False
    window *= base_index_mask
    
    prefix_shape = tuple(
        max(x_size, i_size) for x_size, i_size in zip(x.size(), safe_index.size())
    )[:-1]
    waveform = (
        x.expand(prefix_shape + (-1,))
        .gather(-1, safe_index.expand(prefix_shape + (-1,)))
        .mul_(window)
    )
    waveform *= base_index_mask
    waveform -= window * waveform.sum(-1, keepdim=True).div_(
        window.sum(-1, keepdim=True)
    )
    return waveform, window


def get_centroid(x: torch.Tensor, n_fft: int) -> torch.Tensor:
    """Get centroid for D4C."""
    x = torch.as_tensor(x)
    if D4C_PREVENT_ZERO_DIVISION:
        x = x / x.norm(dim=-1, keepdim=True).clamp(min=6e-8)
    else:
        x = x / x.norm(dim=-1, keepdim=True)
    spec0 = torch.fft.rfft(x, n_fft)
    spec1 = torch.fft.rfft(
        x * torch.arange(1, x.size(-1) + 1, dtype=x.dtype, device=x.device).div_(n_fft),
        n_fft,
    )
    centroid = spec0.real * spec1.real + spec0.imag * spec1.imag
    return centroid


def get_smoothed_power_spec(
    x: torch.Tensor,
    sr: int,
    f0: torch.Tensor,
    position: torch.Tensor,
    n_fft: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Get smoothed power spectrum."""
    x, window = get_windowed_waveform(x, sr, f0, position, 2.0, "hann", n_fft)
    window_weight = window.square().sum(-1, keepdim=True)
    rms = x.square().sum(-1, keepdim=True).div_(window_weight).sqrt_()
    if D4C_PREVENT_ZERO_DIVISION:
        x = x / (rms * math.sqrt(n_fft)).clamp_(min=6e-8)
    smoothed_power_spec = torch.fft.rfft(x, n_fft).abs().square_()
    smoothed_power_spec = dc_correction(smoothed_power_spec, sr, n_fft, f0)
    smoothed_power_spec = linear_smoothing(smoothed_power_spec, sr, n_fft, f0)
    return smoothed_power_spec, rms.detach().squeeze(-1)


def get_static_group_delay(
    static_centroid: torch.Tensor,
    smoothed_power_spec: torch.Tensor,
    sr: int,
    f0: torch.Tensor,
    n_fft: int,
) -> torch.Tensor:
    """Get static group delay."""
    if D4C_PREVENT_ZERO_DIVISION:
        smoothed_power_spec = smoothed_power_spec.clamp(min=6e-8)
    static_group_delay = static_centroid / smoothed_power_spec
    static_group_delay = linear_smoothing(
        static_group_delay, sr, n_fft, f0 * 0.5
    )
    smoothed_group_delay = linear_smoothing(static_group_delay, sr, n_fft, f0)
    static_group_delay = static_group_delay - smoothed_group_delay
    return static_group_delay


def get_coarse_aperiodicity(
    group_delay: torch.Tensor,
    sr: int,
    n_fft: int,
    freq_interval: int,
    n_aperiodicities: int,
    window: torch.Tensor,
) -> torch.Tensor:
    """Get coarse aperiodicity."""
    group_delay = torch.as_tensor(group_delay)
    window = torch.as_tensor(window)
    boundary = int(round(n_fft * 8 / window.size(-1)))
    half_window_length = window.size(-1) // 2
    coarse_aperiodicity = torch.empty(
        group_delay.size()[:-1] + (n_aperiodicities,),
        dtype=group_delay.dtype,
        device=group_delay.device,
    )
    for i in range(n_aperiodicities):
        center = freq_interval * (i + 1) * n_fft // sr
        segment = (
            group_delay[
                ..., center - half_window_length : center + half_window_length + 1
            ]
            * window
        )
        power_spec = torch.fft.rfft(segment, n_fft).abs().square_()
        cumulative_power_spec = power_spec.sort(-1).values.cumsum_(-1)
        if D4C_PREVENT_ZERO_DIVISION:
            cumulative_power_spec.clamp_(min=6e-8)
        coarse_aperiodicity[..., i] = (
            cumulative_power_spec[..., n_fft // 2 - boundary - 1]
            / cumulative_power_spec[..., -1]
        )
    coarse_aperiodicity.log10_().mul_(10.0)
    return coarse_aperiodicity


def d4c_love_train(
    x: torch.Tensor,
    sr: int,
    f0: torch.Tensor,
    position: torch.Tensor,
    threshold: float
) -> int:
    """D4C love train."""
    x = torch.as_tensor(x)
    position = torch.as_tensor(position)
    f0: torch.Tensor = torch.as_tensor(f0)
    vuv = f0 != 0
    lowest_f0 = 40
    f0 = f0.clamp(min=lowest_f0)
    n_fft = 1 << (3 * sr // lowest_f0).bit_length()
    boundary0 = (100 * n_fft - 1) // sr + 1
    boundary1 = (4000 * n_fft - 1) // sr + 1
    boundary2 = (7900 * n_fft - 1) // sr + 1
    waveform, _ = get_windowed_waveform(x, sr, f0, position, 1.5, "blackman", n_fft)
    power_spec = torch.fft.rfft(waveform, n_fft).abs().square_()
    power_spec[..., : boundary0 + 1] = 0.0
    cumulative_spec = power_spec.cumsum_(-1)
    vuv = vuv & (
        cumulative_spec[..., boundary1] > threshold * cumulative_spec[..., boundary2]
    )
    return vuv


def d4c_general_body(
    x: torch.Tensor,
    sr: int,
    f0: torch.Tensor,
    freq_interval: int,
    position: torch.Tensor,
    n_fft: int,
    n_aperiodicities: int,
    window: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """D4C general body."""
    static_centroid = get_static_centroid(x, sr, f0, position, n_fft)
    smoothed_power_spec, rms = get_smoothed_power_spec(x, sr, f0, position, n_fft)
    static_group_delay = get_static_group_delay(
        static_centroid, smoothed_power_spec, sr, f0, n_fft
    )
    coarse_aperiodicity = get_coarse_aperiodicity(
        static_group_delay, sr, n_fft, freq_interval, n_aperiodicities, window
    )
    coarse_aperiodicity.add_((f0[..., None] - 100.0).div_(50.0)).clamp_(max=0.0)
    return coarse_aperiodicity, rms


def linear_smoothing(
    group_delay: torch.Tensor,
    sr: int,
    n_fft: int,
    width: torch.Tensor
) -> torch.Tensor:
    """Linear smoothing for D4C."""
    group_delay = torch.as_tensor(group_delay)
    assert group_delay.size(-1) == n_fft // 2 + 1
    width = torch.as_tensor(width)
    boundary = (width.max() * n_fft / sr).long() + 1
    
    dtype = group_delay.dtype
    device = group_delay.device
    fft_resolution = sr / n_fft
    mirroring_freq_axis = (
        torch.arange(-boundary, n_fft // 2 + 1 + boundary, dtype=dtype, device=device)
        .add(0.5)
        .mul(fft_resolution)
    )
    if group_delay.ndim == 1:
        mirroring_spec = F.pad(
            group_delay[None], (boundary, boundary), mode="reflect"
        ).squeeze_(0)
    elif group_delay.ndim >= 4:
        shape = group_delay.size()
        mirroring_spec = F.pad(
            group_delay.view(math.prod(shape[:-1]), group_delay.size(-1)),
            (boundary, boundary),
            mode="reflect",
        ).view(shape[:-1] + (shape[-1] + 2 * boundary,))
    else:
        mirroring_spec = F.pad(group_delay, (boundary, boundary), mode="reflect")
    mirroring_segment = mirroring_spec.mul(fft_resolution).cumsum_(-1)
    center_freq = torch.arange(n_fft // 2 + 1, dtype=dtype, device=device).mul_(
        fft_resolution
    )
    low_freq = center_freq - width[..., None] * 0.5
    high_freq = center_freq + width[..., None] * 0.5
    levels = interp(
        mirroring_freq_axis, mirroring_segment, torch.cat([low_freq, high_freq], dim=-1)
    )
    low_levels, high_levels = levels.split([n_fft // 2 + 1] * 2, dim=-1)
    smoothed = (high_levels - low_levels).div_(width[..., None])
    return smoothed


def dc_correction(
    spec: torch.Tensor,
    sr: int,
    n_fft: int,
    f0: torch.Tensor
) -> torch.Tensor:
    """DC correction for D4C."""
    spec = torch.as_tensor(spec)
    f0 = torch.as_tensor(f0)
    dtype = spec.dtype
    device = spec.device
    
    upper_limit = 2 + (f0 * (n_fft / sr)).long()
    max_upper_limit = upper_limit.max()
    upper_limit_mask = (
        torch.arange(max_upper_limit - 1, device=device) < (upper_limit - 1)[..., None]
    )
    low_freq_axis = torch.arange(max_upper_limit + 1, dtype=dtype, device=device) * (
        sr / n_fft
    )
    low_freq_replica = interp(
        f0[..., None] - low_freq_axis.flip(-1),
        spec[..., : max_upper_limit + 1].flip(-1),
        low_freq_axis[..., : max_upper_limit - 1] * upper_limit_mask,
    )
    output = spec.clone()
    output[..., : max_upper_limit - 1] += low_freq_replica * upper_limit_mask
    return output


def get_exponential_warmup_scheduler(
    optimizer: "torch.optim.Optimizer",
    warmup_epochs: int,
    decay: float,
) -> "torch.optim.lr_scheduler.LambdaLR":
    """Get exponential warmup learning rate scheduler."""
    def lr_lambda(current_epoch: int) -> float:
        if current_epoch < warmup_epochs:
            return current_epoch / warmup_epochs
        else:
            return decay ** (current_epoch - warmup_epochs)
    
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def prepare_training() -> tuple:
    """Prepare training environment."""
    # Device
    if torch.cuda.is_available():
        device = torch.device("cuda")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        device = torch.device("mps")
    else:
        device = torch.device("cpu")
    print(f"device={device}")
    global _DEVICE_TYPE
    _DEVICE_TYPE = device.type

    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
        torch.backends.cuda.matmul.allow_tf32 = True
    elif device.type == "mps":
        if hasattr(torch.backends.mps, "set_per_process_memory_fraction"):
            torch.backends.mps.set_per_process_memory_fraction(1.0)

    # Config
    h = AttrDict({})
    h = deepcopy(dict_default_hparams)
    print("config:")
    pprint(h)
    print()
    h = AttrDict(h)

    if device.type != "cuda":
        if h.use_amp:
            print("Warning: AMP disabled for non-CUDA device to prevent numerical instability.")
            h.use_amp = False
        if h.compile_convnext or h.compile_d4c or h.compile_discriminator:
            print("Warning: torch.compile disabled for non-CUDA device.")
            h.compile_convnext = False
            h.compile_d4c = False
            h.compile_discriminator = False
    
    # Check directories
    if not "data_dir" in h:
        raise ValueError("data_dir not specified")
    if not "out_dir" in h:
        raise ValueError("out_dir not specified")
    
    in_wav_dataset_dir = Path(h["data_dir"])
    out_dir = Path(h["out_dir"])
    
    if resume:
        latest_checkpoint_file = out_dir / "checkpoint_latest.pt.gz"
        if not latest_checkpoint_file.is_file():
            raise ValueError(f"{latest_checkpoint_file} not found")
    else:
        if out_dir.is_dir():
            if (out_dir / "checkpoint_latest.pt.gz").is_file():
                raise ValueError("checkpoint already exists")
            for file in out_dir.iterdir():
                if file.suffix == ".pt.gz":
                    raise ValueError("output dir contains checkpoint files")
        else:
            out_dir.mkdir(parents=True)
    
    in_ir_wav_dir = repo_root() / h.in_ir_wav_dir
    in_noise_wav_dir = repo_root() / h.in_noise_wav_dir
    in_test_wav_dir = repo_root() / h.in_test_wav_dir
    
    assert in_wav_dataset_dir.is_dir()
    assert out_dir.is_dir()
    assert in_ir_wav_dir.is_dir()
    assert in_noise_wav_dir.is_dir()
    assert in_test_wav_dir.is_dir()
    
    # Load noise and IR files
    noise_files = sorted(
        list(in_noise_wav_dir.rglob("*.wav")) + list(in_noise_wav_dir.rglob("*.flac"))
    )
    if len(noise_files) == 0:
        raise ValueError(f"No audio data in {in_noise_wav_dir}")
    ir_files = sorted(
        list(in_ir_wav_dir.rglob("*.wav")) + list(in_ir_wav_dir.rglob("*.flac"))
    )
    if len(ir_files) == 0:
        raise ValueError(f"No IR data in {in_ir_wav_dir}")
    
    # Get training file list
    min_data_per_speaker = 1
    speakers = []
    training_filelist = []
    speaker_audio_files = []
    for speaker_dir in sorted(in_wav_dataset_dir.iterdir()):
        if not speaker_dir.is_dir():
            continue
        candidates = []
        for wav_file in sorted(speaker_dir.rglob("*")):
            if (
                not wav_file.is_file()
                or wav_file.suffix.lower() not in AUDIO_FILE_SUFFIXES
            ):
                continue
            candidates.append(wav_file)
        if len(candidates) >= min_data_per_speaker:
            speaker_id = len(speakers)
            speakers.append(speaker_dir.name)
            training_filelist.extend([(file, speaker_id) for file in candidates])
            speaker_audio_files.append(candidates)
    
    n_speakers = len(speakers)
    print(f"{n_speakers=}")
    for i, speaker in enumerate(speakers):
        print(f"  {i:{len(str(n_speakers - 1))}d}: {speaker}")
    print()
    
    # Get test file list
    max_n_test_files = 1000
    test_filelist = []
    rng = Random(42)
    target_id_generator = get_target_id_generator(n_speakers)
    for file in sorted(in_test_wav_dir.iterdir())[:max_n_test_files]:
        if file.suffix.lower() not in AUDIO_FILE_SUFFIXES:
            continue
        target_ids = [next(target_id_generator) for _ in range(min(8, n_speakers))]
        test_filelist.append((file, target_ids))
    
    # Compute speaker F0s
    print("Computing mean F0s of target speakers...", end="")
    speaker_f0s = []
    for speaker, files in enumerate(speaker_audio_files):
        if len(files) > 10:
            files = Random(42).sample(files, 10)
        f0 = compute_mean_f0(files)
        speaker_f0s.append(f0)
        if speaker % 5 == 0:
            print()
        print(f"  {speaker:3d}: {f0:.1f}Hz", end=",")
    print()
    print("Done.")
    
    # Compute test pitch shifts
    print("Computing pitch shifts for test files...")
    test_pitch_shifts = []
    source_f0s = []
    for i, (file, target_ids) in enumerate(tqdm(test_filelist, desc="Computing pitch shifts")):
        source_f0 = compute_mean_f0([file], method="harvest")
        source_f0s.append(source_f0)
        if math.isnan(source_f0):
            test_pitch_shifts.append([0] * len(target_ids))
            continue
        pitch_shifts = []
        for target_id in target_ids:
            target_f0 = speaker_f0s[target_id]
            if target_f0 != target_f0:
                pitch_shift = 0
            else:
                pitch_shift = int(round(12.0 * math.log2(target_f0 / source_f0)))
            pitch_shifts.append(pitch_shift)
        test_pitch_shifts.append(pitch_shifts)
    print("Done.")
    
    # Create dataset
    training_dataset = WavDataset(
        training_filelist,
        in_sample_rate=h.in_sample_rate,
        out_sample_rate=h.out_sample_rate,
        wav_length=h.wav_length,
        segment_length=h.segment_length,
        noise_files=noise_files,
        ir_files=ir_files,
        augmentation_snr_candidates=h.augmentation_snr_candidates,
        augmentation_formant_shift_probability=h.augmentation_formant_shift_probability,
        augmentation_formant_shift_semitone_min=h.augmentation_formant_shift_semitone_min,
        augmentation_formant_shift_semitone_max=h.augmentation_formant_shift_semitone_max,
        augmentation_reverb_probability=h.augmentation_reverb_probability,
        augmentation_lpf_probability=h.augmentation_lpf_probability,
        augmentation_lpf_cutoff_freq_candidates=h.augmentation_lpf_cutoff_freq_candidates,
    )
    training_loader = torch.utils.data.DataLoader(
        training_dataset,
        num_workers=min(h.num_workers, os.cpu_count()),
        collate_fn=training_dataset.collate,
        shuffle=True,
        sampler=None,
        batch_size=h.batch_size,
        pin_memory=True,
        drop_last=True,
        persistent_workers=True,
    )
    
    # Load pretrained models
    phone_extractor = PhoneExtractor().to(device).eval().requires_grad_(False)
    phone_extractor_checkpoint = torch.load(
        repo_root() / h.phone_extractor_file, map_location="cpu", weights_only=True
    )
    print(
        phone_extractor.load_state_dict(
            phone_extractor_checkpoint["phone_extractor"], strict=False
        )
    )
    del phone_extractor_checkpoint
    
    pitch_estimator = PitchEstimator().to(device).eval().requires_grad_(False)
    pitch_estimator_checkpoint = torch.load(
        repo_root() / h.pitch_estimator_file, map_location="cpu", weights_only=True
    )
    print(
        pitch_estimator.load_state_dict(pitch_estimator_checkpoint["pitch_estimator"])
    )
    del pitch_estimator_checkpoint
    
    # Create models
    net_g = ConverterNetwork(
        phone_extractor,
        pitch_estimator,
        n_speakers,
        h.pitch_bins,
        h.hidden_channels,
        h.vq_topk,
        h.training_time_vq,
        h.phone_noise_ratio,
        h.floor_noise_level,
    ).to(device)
    net_d = MultiPeriodDiscriminator(san=h.san).to(device)
    
    # Optimizers
    optim_g = torch.optim.AdamW(
        net_g.parameters(),
        h.learning_rate_g,
        betas=h.adam_betas,
        eps=h.adam_eps,
    )
    optim_d = torch.optim.AdamW(
        net_d.parameters(),
        h.learning_rate_d,
        betas=h.adam_betas,
        eps=h.adam_eps,
    )
    
    grad_scaler = torch.amp.GradScaler(_DEVICE_TYPE, enabled=h.use_amp)
    grad_balancer = GradBalancer(
        weights={
            "loss_loudness": h.grad_weight_loudness,
            "loss_mel": h.grad_weight_mel,
            "loss_adv": h.grad_weight_adv,
            "loss_fm": h.grad_weight_fm,
        }
        | ({"loss_ap": h.grad_weight_ap} if h.grad_weight_ap else {}),
        ema_decay=h.grad_balancer_ema_decay,
    )
    
    # Checkpoint loading
    initial_iteration = 0
    if resume:
        checkpoint_file = latest_checkpoint_file
    elif h.pretrained_file is not None:
        checkpoint_file = repo_root() / h.pretrained_file
    else:
        checkpoint_file = None
    
    if checkpoint_file is not None:
        with gzip.open(checkpoint_file, "rb") as f:
            checkpoint = torch.load(f, map_location="cpu", weights_only=True)
        if not resume and not skip_training:
            initial_speaker_embedding = checkpoint["net_g"]["embed_speaker.weight"][:1]
            initial_speaker_embedding_for_cross_attention = checkpoint["net_g"][
                "key_value_speaker_embedding.weight"
            ][:1]
            checkpoint["net_g"]["embed_speaker.weight"] = initial_speaker_embedding[
                [0] * n_speakers
            ]
            checkpoint["net_g"]["key_value_speaker_embedding.weight"] = (
                initial_speaker_embedding_for_cross_attention[[0] * n_speakers]
            )
            checkpoint["net_g"]["vq.codebooks"] = checkpoint["net_g"]["vq.codebooks"][
                [0] * n_speakers
            ]
        print(net_g.load_state_dict(checkpoint["net_g"], strict=False))
        print(net_d.load_state_dict(checkpoint["net_d"], strict=False))
        if resume or skip_training:
            optim_g.load_state_dict(
                get_decompressed_optimizer_state_dict(checkpoint["optim_g"])
            )
            optim_d.load_state_dict(
                get_decompressed_optimizer_state_dict(checkpoint["optim_d"])
            )
            initial_iteration = checkpoint["iteration"]
        grad_balancer.load_state_dict(checkpoint["grad_balancer"])
        grad_scaler.load_state_dict(checkpoint["grad_scaler"])
    
    # Initialize VQ codebooks
    def wav_iterator(files):
        for file in files:
            wav, sr = torchaudio.load(file)
            wav = wav.to(device)
            if sr != h.in_sample_rate:
                wav = get_resampler(sr, h.in_sample_rate, device)(wav)
            yield wav[:, None, :]
    
    if resume:
        net_g.enable_hook()
    else:
        net_g.initialize_vq([wav_iterator(files) for files in speaker_audio_files])
    
    # Schedulers
    scheduler_g = get_exponential_warmup_scheduler(
        optim_g, h.warmup_steps, h.learning_rate_decay
    )
    scheduler_d = get_exponential_warmup_scheduler(
        optim_d, h.warmup_steps, h.learning_rate_decay
    )
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message=r"Detected call of `lr_scheduler\.step\(\)` before `optimizer\.step\(\)`",
        )
        for _ in range(initial_iteration + 1):
            scheduler_g.step()
            scheduler_d.step()
    
    net_g.train()
    net_d.train()
    
    # Setup logging
    dict_scalars = defaultdict(list)
    quality_tester = QualityTester().eval().to(device)
    if skip_training:
        writer = None
    else:
        writer = SummaryWriter(out_dir)
        if not h.record_metrics:
            writer.add_scalar = lambda *args, **kwargs: None
            writer.add_histogram = lambda *args, **kwargs: None
        writer.add_text(
            "log",
            f"start training w/ {torch.cuda.get_device_name(device) if device.type == 'cuda' else device.type}.",
            initial_iteration,
        )
    if not resume:
        with open(out_dir / "config.json", "w", encoding="utf-8") as f:
            json.dump(dict(h), f, indent=4)
        if not is_notebook():
            shutil.copy(__file__, out_dir)
    
    return (
        device,
        in_wav_dataset_dir,
        h,
        out_dir,
        speakers,
        test_filelist,
        training_loader,
        speaker_f0s,
        test_pitch_shifts,
        phone_extractor,
        pitch_estimator,
        net_g,
        net_d,
        optim_g,
        optim_d,
        grad_scaler,
        grad_balancer,
        resample_to_in_sample_rate,
        initial_iteration,
        scheduler_g,
        scheduler_d,
        dict_scalars,
        quality_tester,
        writer,
    )


def compute_mean_f0(
    files: list[Path],
    method: Literal["dio", "harvest"] = "dio"
) -> float:
    """Compute mean F0 from audio files."""
    import numpy as np
    import pyworld
    import torch
    
    sum_log_f0 = 0.0
    n_frames = 0
    
    for file in files:
        wav, sr = torchaudio.load(file)
        if method == "dio":
            f0, _ = pyworld.dio(wav.ravel().numpy().astype(np.float64), sr)
        elif method == "harvest":
            f0, _ = pyworld.harvest(wav.ravel().numpy().astype(np.float64), sr)
        else:
            raise ValueError(f"Invalid method: {method}")
        f0 = f0[f0 > 0]
        sum_log_f0 += float(np.log(f0).sum())
        n_frames += len(f0)
    
    if n_frames == 0:
        return float("nan")
    mean_log_f0 = sum_log_f0 / n_frames
    return math.exp(mean_log_f0)


def get_target_id_generator(n_speakers: int):
    """Generator for target IDs."""
    if n_speakers > 8:
        while True:
            order = list(range(n_speakers))
            rng.shuffle(order)
            yield from order
    else:
        while True:
            yield from range(n_speakers)


def get_compressed_optimizer_state_dict(optimizer: "torch.optim.Optimizer") -> dict:
    """Compress optimizer state dict to bfloat16."""
    state_dict = {}
    for k0, v0 in optimizer.state_dict().items():
        if k0 != "state":
            state_dict[k0] = v0
            continue
        state_dict[k0] = {}
        for k1, v1 in v0.items():
            state_dict[k0][k1] = {}
            for k2, v2 in v1.items():
                if isinstance(v2, torch.Tensor):
                    state_dict[k0][k1][k2] = v2.bfloat16()
                else:
                    state_dict[k0][k1][k2] = v2
    return state_dict


def get_decompressed_optimizer_state_dict(compressed_state_dict: dict) -> dict:
    """Decompress optimizer state dict back to float."""
    state_dict = {}
    for k0, v0 in compressed_state_dict.items():
        if k0 != "state":
            state_dict[k0] = v0
            continue
        state_dict[k0] = {}
        for k1, v1 in v0.items():
            state_dict[k0][k1] = {}
            for k2, v2 in v1.items():
                if isinstance(v2, torch.Tensor):
                    state_dict[k0][k1][k2] = v2.float()
                else:
                    state_dict[k0][k1][k2] = v2
    return state_dict
