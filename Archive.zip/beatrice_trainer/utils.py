"""Beatrice Trainer — Utility functions."""

import math
from pathlib import Path
from typing import Union, Literal

import numpy as np
import pyworld
import torch
import torch.nn as nn
import torchaudio
import torch.nn.functional as F

from ._compat import is_notebook, repo_root, PARAPHERNALIA_VERSION

# ── Module-level caches ──────────────────────────────────────────────────────
_resampler_cache: dict = {}
_butterworth_cache: dict = {}


def compute_loudness(
    x: torch.Tensor, sr: int, win_lengths: list[int]
) -> list[torch.Tensor]:
    # x: [batch_size, wav_length]
    assert x.ndim == 2
    n_fft = 2048
    chunk_length = n_fft // 2
    n_taps = chunk_length + 1

    # Run on CPU to avoid MPS FFT NaN issues
    # Keep requires_grad by not detaching
    target_device = x.device  # capture BEFORE moving to CPU
    requires_grad = x.requires_grad
    x = x.cpu().float()

    if not hasattr(compute_loudness, "filter"):
        compute_loudness.filter = {}
    if not hasattr(compute_loudness, "_hann_windows"):
        compute_loudness._hann_windows = {}

    results = []
    with torch.amp.autocast("cpu", enabled=False):
        cache_key = (sr, str(target_device))
        if cache_key not in compute_loudness.filter:
            # MPS doesn't support float64; compute on CPU and transfer
            ir_cpu = torch.zeros(n_taps, dtype=torch.float64)
            ir_cpu[0] = 0.5
            ir_cpu = torchaudio.functional.treble_biquad(
                ir_cpu, sr, 4.0, 1500.0, 1.0 / math.sqrt(2)
            )
            ir_cpu = torchaudio.functional.highpass_biquad(ir_cpu, sr, 38.0, 0.5)
            ir_cpu *= 2.0
            # Keep filter on CPU since all FFT ops below run on CPU
            compute_loudness.filter[cache_key] = torch.fft.rfft(ir_cpu, n=n_fft).to(
                torch.complex64
            )

        x = x.float()
        wav_length = x.size(-1)
        if wav_length % chunk_length != 0:
            x = F.pad(x, (0, chunk_length - wav_length % chunk_length))
        padded_wav_length = x.size(-1)
        x = x.view(x.size()[:-1] + (padded_wav_length // chunk_length, chunk_length))
        x = torch.fft.irfft(
            torch.fft.rfft(x, n=n_fft) * compute_loudness.filter[cache_key],
            n=n_fft,
        ).contiguous()  # Ensure contiguous for fold operation on MPS
        x = F.fold(
            x.transpose(-2, -1).contiguous(),  # transpose creates non-contiguous view
            (1, padded_wav_length + chunk_length),
            (1, n_fft),
            stride=(1, chunk_length),
        ).squeeze((-3, -2))[..., :wav_length]

        x = x.square()
        for win_length in win_lengths:
            hop_length = win_length // 4
            # [..., n_frames]
            win_key = (win_length, str(x.device))
            if win_key not in compute_loudness._hann_windows:
                compute_loudness._hann_windows[win_key] = torch.hann_window(win_length, device=x.device)
            window = compute_loudness._hann_windows[win_key]
            energy = (
                x.unfold(-1, win_length, hop_length)
                .matmul(window)
                .add(win_length / 4.0 * 1e-5)
                .clamp(min=1e-10).log()  # Use out-of-place for MPS safety
            )
            # フィルタリング後の波形が振幅 1 の正弦波なら大体 log10(win_length/4), 1 の差は 10dB の差
            results.append(energy)
    # Move results back to target device
    return [r.to(target_device) for r in results]


def _normalize(tensor: torch.Tensor, dim: int) -> torch.Tensor:
    denom = tensor.norm(p=2.0, dim=dim, keepdim=True).clamp_min(1e-6)
    return tensor / denom


def compute_grad_norm(
    model: nn.Module, return_stats: bool = False
) -> Union[float, dict[str, float]]:
    norms_sq = []
    stats = {}
    for name, p in model.named_parameters():
        if p.grad is None:
            continue
        grad_norm = p.grad.data.float().norm()
        if not grad_norm.isfinite():
            grad_norm = grad_norm.nan_to_num(0.0)
        norms_sq.append(grad_norm.square())
        if return_stats:
            stats[f"grad_norm_{name}"] = grad_norm
    if not norms_sq:
        total_norm = 0.0
    else:
        total_norm_sq = torch.stack(norms_sq).sum()
        total_norm = total_norm_sq.sqrt().item() if not return_stats else torch.sqrt(total_norm_sq).item()
    if return_stats:
        # Resolve stats values with single batched item() call
        if stats:
            keys = list(stats.keys())
            vals = torch.stack([stats[k] for k in keys])
            vals_items = vals.tolist()
            stats = {k: v for k, v in zip(keys, vals_items)}
        return total_norm, stats
    return total_norm


def _compute_f0_for_file(file, method="dio"):
    wav, sr = torchaudio.load(file)
    wav_np = wav.ravel().numpy().astype(np.float64)
    if method == "dio":
        f0, _ = pyworld.dio(wav_np, sr)
    elif method == "harvest":
        f0, _ = pyworld.harvest(wav_np, sr)
    else:
        raise ValueError(f"Invalid method: {method}")
    f0 = f0[f0 > 0]
    if len(f0) == 0:
        return 0.0, 0
    return float(np.log(f0).sum()), len(f0)


def compute_mean_f0(
    files: list[Path], method: Literal["dio", "harvest"] = "dio"
) -> float:
    from concurrent.futures import ThreadPoolExecutor

    if len(files) <= 2:
        results = [_compute_f0_for_file(f, method) for f in files]
    else:
        with ThreadPoolExecutor(max_workers=min(4, len(files))) as ex:
            results = list(ex.map(lambda f: _compute_f0_for_file(f, method), files))
    sum_log_f0 = sum(r[0] for r in results)
    n_frames = sum(r[1] for r in results)
    if n_frames == 0:
        return math.nan
    return math.exp(sum_log_f0 / n_frames)


def slice_segments(
    x: torch.Tensor, start_indices: torch.Tensor, segment_length: int
) -> torch.Tensor:
    batch_size, channels, _ = x.size()
    # [batch_size, 1, segment_size]
    indices = start_indices[:, None, None] + torch.arange(
        segment_length, device=start_indices.device
    )
    # [batch_size, channels, segment_size]
    indices = indices.expand(batch_size, channels, segment_length)
    return x.gather(2, indices)


# %% [markdown]
# ## Dataset


# %%

def get_resampler(
    sr_before: int, sr_after: int, device="cpu"
) -> torchaudio.transforms.Resample:
    if not isinstance(device, str):
        device = str(device)
    # CRITICAL: Do NOT cache resamplers on MPS — cached MPS resamplers
    # produce NaN. This is a known PyTorch MPS backend bug.
    if device == "mps":
        return torchaudio.transforms.Resample(sr_before, sr_after).to(device)
    key = (sr_before, sr_after, device)
    if key not in _resampler_cache:
        _resampler_cache[key] = torchaudio.transforms.Resample(
            sr_before, sr_after
        ).to(device)
    return _resampler_cache[key]


def convolve(signal: torch.Tensor, ir: torch.Tensor) -> torch.Tensor:
    n = 1 << (signal.size(-1) + ir.size(-1) - 2).bit_length()
    res = torch.fft.irfft(torch.fft.rfft(signal, n=n) * torch.fft.rfft(ir, n=n), n=n)
    return res[..., : signal.size(-1)]


def get_butterworth_lpf(
    cutoff_freq: float, sample_rate: int
) -> tuple[torch.Tensor, torch.Tensor]:
    key = (cutoff_freq, sample_rate)
    if key not in _butterworth_cache:
        q = math.sqrt(0.5)
        omega = math.tau * cutoff_freq / sample_rate
        cos_omega = math.cos(omega)
        alpha = math.sin(omega) / (2.0 * q)
        b1 = (1.0 - cos_omega) / (1.0 + alpha)
        b0 = b1 * 0.5
        a1 = -2.0 * cos_omega / (1.0 + alpha)
        a2 = (1.0 - alpha) / (1.0 + alpha)
        _butterworth_cache[key] = (
            torch.tensor([b0, b1, b0]),
            torch.tensor([1.0, a1, a2]),
        )
    return _butterworth_cache[key]


def get_compressed_optimizer_state_dict(
    optimizer: torch.optim.Optimizer,
) -> dict:
    state_dict = {}
    for k0, v0 in optimizer.state_dict().items():
        if k0 != "state":
            state_dict[k0] = v0
            continue
        state_dict[k0] = {}
        for k1, v1 in v0.items():
            state_dict[k0][k1] = {}
            for k2, v2 in v1.items():
                if isinstance(v2, torch.Tensor):
                    state_dict[k0][k1][k2] = v2.bfloat16()
                else:
                    state_dict[k0][k1][k2] = v2
    return state_dict


def get_decompressed_optimizer_state_dict(compressed_state_dict: dict) -> dict:
    state_dict = {}
    for k0, v0 in compressed_state_dict.items():
        if k0 != "state":
            state_dict[k0] = v0
            continue
        state_dict[k0] = {}
        for k1, v1 in v0.items():
            state_dict[k0][k1] = {}
            for k2, v2 in v1.items():
                if isinstance(v2, torch.Tensor):
                    state_dict[k0][k1][k2] = v2.float()
                else:
                    state_dict[k0][k1][k2] = v2
    return state_dict
