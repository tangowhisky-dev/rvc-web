"""Utility functions.

Helper functions for path handling, device management, and general utilities.
"""

import os
from pathlib import Path
from typing import Optional


def is_notebook() -> bool:
    """Check if running in Jupyter notebook context."""
    return "get_ipython" in globals()


def repo_root() -> Path:
    """Get the repository root directory."""
    d = Path(__file__).parent
    assert d.is_absolute(), d
    for d in d.parents:
        if (d / ".git").is_dir():
            return d
    raise RuntimeError("Repository root not found")


def get_resampler(
    sr_before: int,
    sr_after: int,
    device: Optional[str] = None,
    cache: Optional[dict] = None
) -> "torchaudio.transforms.Resample":
    """Get or create a resampler with caching."""
    if cache is None:
        cache = {}
    
    if device is None:
        device = "cpu"
    
    key = (sr_before, sr_after, device)
    if key in cache:
        return cache[key]
    
    import torchaudio
    resampler = torchaudio.transforms.Resample(sr_before, sr_after).to(device)
    cache[key] = resampler
    return resampler


def compute_mean_f0(
    files: list[Path],
    method: str = "dio"
) -> float:
    """Compute mean F0 from audio files."""
    import numpy as np
    import pyworld
    import torch
    
    sum_log_f0 = 0.0
    n_frames = 0
    
    for file in files:
        wav, sr = torchaudio.load(file)
        if method == "dio":
            f0, _ = pyworld.dio(wav.ravel().numpy().astype(np.float64), sr)
        elif method == "harvest":
            f0, _ = pyworld.harvest(wav.ravel().numpy().astype(np.float64), sr)
        else:
            raise ValueError(f"Invalid method: {method}")
        f0 = f0[f0 > 0]
        sum_log_f0 += float(np.log(f0).sum())
        n_frames += len(f0)
    
    if n_frames == 0:
        return float("nan")
    mean_log_f0 = sum_log_f0 / n_frames
    return math.exp(mean_log_f0)


def get_compressed_optimizer_state_dict(optimizer: "torch.optim.Optimizer") -> dict:
    """Compress optimizer state dict to bfloat16."""
    state_dict = {}
    for k0, v0 in optimizer.state_dict().items():
        if k0 != "state":
            state_dict[k0] = v0
            continue
        state_dict[k0] = {}
        for k1, v1 in v0.items():
            state_dict[k0][k1] = {}
            for k2, v2 in v1.items():
                if isinstance(v2, torch.Tensor):
                    state_dict[k0][k1][k2] = v2.bfloat16()
                else:
                    state_dict[k0][k1][k2] = v2
    return state_dict


def get_decompressed_optimizer_state_dict(compressed_state_dict: dict) -> dict:
    """Decompress optimizer state dict back to float."""
    state_dict = {}
    for k0, v0 in compressed_state_dict.items():
        if k0 != "state":
            state_dict[k0] = v0
            continue
        state_dict[k0] = {}
        for k1, v1 in v0.items():
            state_dict[k0][k1] = {}
            for k2, v2 in v1.items():
                if isinstance(v2, torch.Tensor):
                    state_dict[k0][k1][k2] = v2.float()
                else:
                    state_dict[k0][k1][k2] = v2
    return state_dict


def compute_grad_norm(model: "torch.nn.Module", return_stats: bool = False) -> float:
    """Compute gradient norm of model parameters."""
    import math
    total_norm = 0.0
    stats = {}
    
    for name, p in model.named_parameters():
        if p.grad is None:
            continue
        param_norm = p.grad.data.norm().item()
        if not math.isfinite(param_norm):
            param_norm = p.grad.data.float().norm().item()
        total_norm += param_norm * param_norm
        if return_stats:
            stats[f"grad_norm_{name}"] = param_norm
    total_norm = math.sqrt(total_norm)
    if return_stats:
        return total_norm, stats
    return total_norm
