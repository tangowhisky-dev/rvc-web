"""Main entry point.

CLI interface and training loop.
"""

import argparse
import gc
import json
import math
import os
import random
import shutil
import sys
import warnings
from collections import defaultdict
from contextlib import nullcontext
from copy import deepcopy
from pathlib import Path
from typing import Optional, Union, Literal

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchaudio
from torch.utils.tensorboard import SummaryWriter
from tqdm.auto import tqdm

from .config import prepare_training_configs, prepare_training_configs_for_experiment
from .models import (
    ConvNeXtBlock,
    ConvNeXtStack,
    CrossAttention,
    MultiPeriodDiscriminator,
    dump_params,
    dump_layer,
)
from .utils import get_resampler
from .dataset import WavDataset, augment_audio
from .extractor import (
    PitchEstimator,
    PhoneExtractor,
    extract_pitch_features,
)
from .trainer import (
    get_compressed_optimizer_state_dict,
    get_decompressed_optimizer_state_dict,
)
from .models import GradBalancer
from .utils import compute_grad_norm, compute_mean_f0
from .utils import repo_root

AUDIO_FILE_SUFFIXES = (".wav", ".flac")

# Device type string, used by torch.autocast and GradScaler.
# Will be set dynamically in prepare_training() based on available backend.
_DEVICE_TYPE = "cuda"


def is_notebook():
    return "ipykernel" in sys.modules


def main():
    parser = argparse.ArgumentParser(description="Beatrice trainer")
    parser.add_argument("-c", "--config", type=str, required=True, help="Config JSON file")
    parser.add_argument("-r", "--resume", type=str, default=None, help="Resume from checkpoint")
    parser.add_argument("-s", "--skip-training", type=bool, default=False, help="Skip training")
    args = parser.parse_args()
    
    resume = args.resume is not None
    skip_training = args.skip_training
    
    # Load config
    config_path = Path(args.config)
    if not config_path.is_file():
        raise FileNotFoundError(f"Config not found: {config_path}")
    
    with open(config_path, encoding="utf-8") as f:
        h = json.load(f)
    
    # Fill defaults
    def_default_hparams = {
        # training
        "learning_rate_g": 5e-5,
        "learning_rate_d": 5e-5,
        "learning_rate_decay": 0.999999,
        "adam_betas": [0.8, 0.99],
        "adam_eps": 1e-6,
        "batch_size": 8,
        "grad_weight_loudness": 1.0,  # grad_weight は比が同じなら同じ意味になるはず
        "grad_weight_mel": 50.0,
        "grad_weight_ap": 100.0,
        "grad_weight_adv": 150.0,
        "grad_weight_fm": 150.0,
        "grad_balancer_ema_decay": 0.995,
        "use_amp": True,
        "num_workers": 16,
        "n_steps": 10,  # 変更不可
        "warmup_steps": 5000,
        "evaluation_interval": 2000,
        "save_interval": 2000,
        "in_sample_rate": 16000,  # 変更不可
        "out_sample_rate": 24000,  # 変更不可
        "wav_length": 4 * 24000,  # 4s
        "segment_length": 100,  # 1s
        "phone_noise_ratio": 0.5,
        "vq_topk": 4,
        "training_time_vq": "none",  # "none", "self" or "random"
        "floor_noise_level": 1e-3,
        "record_metrics": False,
        # augmentation
        "augmentation_snr_candidates": [20.0, 25.0, 30.0, 35.0, 40.0, 45.0],
        "augmentation_formant_shift_probability": 0.5,
        "augmentation_formant_shift_semitone_min": -3.0,
        "augmentation_formant_shift_semitone_max": 3.0,
        "augmentation_reverb_probability": 0.5,
        "augmentation_lpf_probability": 0.2,
        "augmentation_lpf_cutoff_freq_candidates": [2000.0, 3000.0, 4000.0, 6000.0],
        # data
        "phone_extractor_file": "assets/pretrained/122_checkpoint_03000000.pt",
        "pitch_estimator_file": "assets/pretrained/104_3_checkpoint_00300000.pt",
        "in_ir_wav_dir": "assets/ir",
        "in_noise_wav_dir": "assets/noise",
        "in_test_wav_dir": "assets/test",
        "pretrained_file": "assets/pretrained/151_checkpoint_libritts_r_200_02750000.pt.gz",  # None も可
        # model
        "pitch_bins": 448,  # 変更不可
        "hidden_channels": 256,  # ファインチューン時変更不可、変更した場合は推論側の対応必要
        "san": False,  # ファインチューン時変更不可
        "compile_convnext": False,
        "compile_d4c": False,
        "compile_discriminator": False,
        "profile": False,
    }
    
    for key in def_default_hparams.keys():
        if key not in h:
            h[key] = def_default_hparams[key]
            warnings.warn(f"{key} not in config, using default: {h[key]}")

    # Setup device with CUDA -> MPS -> CPU fallback
    if torch.cuda.is_available():
        device = torch.device("cuda")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        device = torch.device("mps")
    else:
        device = torch.device("cpu")

    _DEVICE_TYPE = device.type

    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
        torch.backends.cuda.matmul.allow_tf32 = True
    elif device.type == "mps":
        if hasattr(torch.backends.mps, "set_per_process_memory_fraction"):
            torch.backends.mps.set_per_process_memory_fraction(1.0)

    if device.type != "cuda":
        if h["use_amp"]:
            print("Warning: AMP disabled for non-CUDA device to prevent numerical instability.")
            h["use_amp"] = False
        if h.get("compile_convnext") or h.get("compile_d4c") or h.get("compile_discriminator"):
            print("Warning: torch.compile disabled for non-CUDA device.")
            h["compile_convnext"] = False
            h["compile_d4c"] = False
            h["compile_discriminator"] = False

    # Setup paths
    repo_root = Path(__file__).parent.parent
    
    in_wav_dataset_dir = repo_root / h["data_dir"]
    out_dir = repo_root / h["out_dir"]

    if not resume:
        out_dir.mkdir(parents=True, exist_ok=True)
    
    in_ir_wav_dir = repo_root / h["in_ir_wav_dir"]
    in_noise_wav_dir = repo_root / h["in_noise_wav_dir"]
    in_test_wav_dir = repo_root / h["in_test_wav_dir"]
    
    assert in_wav_dataset_dir.is_dir(), in_wav_dataset_dir
    assert out_dir.is_dir(), out_dir
    assert in_ir_wav_dir.is_dir(), in_ir_wav_dir
    assert in_noise_wav_dir.is_dir(), in_noise_wav_dir
    assert in_test_wav_dir.is_dir(), in_test_wav_dir
    
    # Load audio files
    noise_files = sorted(
        list(in_noise_wav_dir.rglob("*.wav")) + list(in_noise_wav_dir.rglob("*.flac"))
    )
    if len(noise_files) == 0:
        raise ValueError(f"No audio data in {in_noise_wav_dir}")
    ir_files = sorted(
        list(in_ir_wav_dir.rglob("*.wav")) + list(in_ir_wav_dir.rglob("*.flac"))
    )
    if len(ir_files) == 0:
        raise ValueError(f"No IR data in {in_ir_wav_dir}")
    
    # Get training file list
    min_data_per_speaker = 1
    speakers = []
    training_filelist = []
    speaker_audio_files = []
    for speaker_dir in sorted(in_wav_dataset_dir.iterdir()):
        if not speaker_dir.is_dir():
            continue
        candidates = []
        for wav_file in sorted(speaker_dir.rglob("*")):
            if (
                not wav_file.is_file()
                or wav_file.suffix.lower() not in AUDIO_FILE_SUFFIXES
            ):
                continue
            candidates.append(wav_file)
        if len(candidates) >= min_data_per_speaker:
            speaker_id = len(speakers)
            speakers.append(speaker_dir.name)
            training_filelist.extend([(file, speaker_id) for file in candidates])
            speaker_audio_files.append(candidates)
    
    n_speakers = len(speakers)
    if n_speakers == 0:
        raise ValueError(f"No speaker data in {in_wav_dataset_dir}")
    print(f"{n_speakers=}")
    for i, speaker in enumerate(speakers):
        print(f"  {i:{len(str(n_speakers - 1))}d}: {speaker}")
    print()
    print(f"{len(training_filelist)=}")
    
    # Get test file list
    max_n_test_files = 1000
    test_filelist = []
    target_id_generator = get_target_id_generator(n_speakers)
    for file in sorted(in_test_wav_dir.iterdir())[:max_n_test_files]:
        if file.suffix.lower() not in AUDIO_FILE_SUFFIXES:
            continue
        target_ids = [next(target_id_generator) for _ in range(min(8, n_speakers))]
        test_filelist.append((file, target_ids))
    
    # Compute speaker F0s
    print("Computing mean F0s of target speakers...", end="")
    speaker_f0s = []
    for speaker, files in enumerate(speaker_audio_files):
        if len(files) > 10:
            files = random.sample(files, 10)
        f0 = compute_mean_f0(files)
        speaker_f0s.append(f0)
        if speaker % 5 == 0:
            print()
        print(f"  {speaker:3d}: {f0:.1f}Hz", end=",")
    print()
    print("Done.")
    
    # Compute test pitch shifts
    print("Computing pitch shifts for test files...")
    test_pitch_shifts = []
    source_f0s = []
    for i, (file, target_ids) in enumerate(tqdm(test_filelist, desc="Computing pitch shifts")):
        source_f0 = compute_mean_f0([file], method="harvest")
        source_f0s.append(source_f0)
        if math.isnan(source_f0):
            test_pitch_shifts.append([0] * len(target_ids))
            continue
        pitch_shifts = []
        for target_id in target_ids:
            target_f0 = speaker_f0s[target_id]
            if target_f0 != target_f0:
                pitch_shift = 0
            else:
                pitch_shift = int(round(12.0 * math.log2(target_f0 / source_f0)))
            pitch_shifts.append(pitch_shift)
        test_pitch_shifts.append(pitch_shifts)
    print("Done.")
    
    # Create dataset
    training_dataset = WavDataset(
        training_filelist,
        in_sample_rate=h["in_sample_rate"],
        out_sample_rate=h["out_sample_rate"],
        wav_length=h["wav_length"],
        segment_length=h["segment_length"],
        noise_files=noise_files,
        ir_files=ir_files,
        augmentation_snr_candidates=h["augmentation_snr_candidates"],
        augmentation_formant_shift_probability=h["augmentation_formant_shift_probability"],
        augmentation_formant_shift_semitone_min=h["augmentation_formant_shift_semitone_min"],
        augmentation_formant_shift_semitone_max=h["augmentation_formant_shift_semitone_max"],
        augmentation_reverb_probability=h["augmentation_reverb_probability"],
        augmentation_lpf_probability=h["augmentation_lpf_probability"],
        augmentation_lpf_cutoff_freq_candidates=h["augmentation_lpf_cutoff_freq_candidates"],
    )
    training_loader = torch.utils.data.DataLoader(
        training_dataset,
        num_workers=min(h["num_workers"], os.cpu_count()),
        collate_fn=training_dataset.collate,
        shuffle=True,
        sampler=None,
        batch_size=h["batch_size"],
        pin_memory=True,
        drop_last=True,
        persistent_workers=True,
    )
    
    # Load pretrained models
    phone_extractor = PhoneExtractor().to(device).eval().requires_grad_(False)
    phone_extractor_checkpoint = torch.load(
        repo_root / h["phone_extractor_file"], map_location="cpu", weights_only=True
    )
    print(
        phone_extractor.load_state_dict(
            phone_extractor_checkpoint["phone_extractor"], strict=False
        )
    )
    del phone_extractor_checkpoint
    
    pitch_estimator = PitchEstimator().to(device).eval().requires_grad_(False)
    pitch_estimator_checkpoint = torch.load(
        repo_root / h["pitch_estimator_file"], map_location="cpu", weights_only=True
    )
    print(
        pitch_estimator.load_state_dict(pitch_estimator_checkpoint["pitch_estimator"])
    )
    del pitch_estimator_checkpoint
    
    # Create models
    net_g = ConverterNetwork(
        phone_extractor,
        pitch_estimator,
        n_speakers,
        h["pitch_bins"],
        h["hidden_channels"],
        h["vq_topk"],
        h["training_time_vq"],
        h["phone_noise_ratio"],
        h["floor_noise_level"],
    ).to(device)
    net_d = MultiPeriodDiscriminator(san=h["san"]).to(device)
    
    # Optimizers
    optim_g = torch.optim.AdamW(
        net_g.parameters(),
        h["learning_rate_g"],
        betas=h["adam_betas"],
        eps=h["adam_eps"],
    )
    optim_d = torch.optim.AdamW(
        net_d.parameters(),
        h["learning_rate_d"],
        betas=h["adam_betas"],
        eps=h["adam_eps"],
    )
    
    grad_scaler = torch.amp.GradScaler(_DEVICE_TYPE, enabled=h["use_amp"])
    grad_balancer = GradBalancer(
        weights={
            "loss_loudness": h["grad_weight_loudness"],
            "loss_mel": h["grad_weight_mel"],
            "loss_adv": h["grad_weight_adv"],
            "loss_fm": h["grad_weight_fm"],
        }
        | ({"loss_ap": h["grad_weight_ap"]} if h["grad_weight_ap"] else {}),
        ema_decay=h["grad_balancer_ema_decay"],
    )
    
    # Checkpoint loading
    initial_iteration = 0
    if resume:
        checkpoint_file = latest_checkpoint_file
    elif h["pretrained_file"] is not None:
        checkpoint_file = repo_root / h["pretrained_file"]
    else:
        checkpoint_file = None
    
    if checkpoint_file is not None:
        with gzip.open(checkpoint_file, "rb") as f:
            checkpoint = torch.load(f, map_location="cpu", weights_only=True)
        if not resume and not skip_training:
            initial_speaker_embedding = checkpoint["net_g"]["embed_speaker.weight"][:1]
            initial_speaker_embedding_for_cross_attention = checkpoint["net_g"][
                "key_value_speaker_embedding.weight"
            ][:1]
            checkpoint["net_g"]["embed_speaker.weight"] = initial_speaker_embedding[
                [0] * n_speakers
            ]
            checkpoint["net_g"]["key_value_speaker_embedding.weight"] = (
                initial_speaker_embedding_for_cross_attention[[0] * n_speakers]
            )
            checkpoint["net_g"]["vq.codebooks"] = checkpoint["net_g"]["vq.codebooks"][
                [0] * n_speakers
            ]
        print(net_g.load_state_dict(checkpoint["net_g"], strict=False))
        print(net_d.load_state_dict(checkpoint["net_d"], strict=False))
        if resume or skip_training:
            optim_g.load_state_dict(
                get_decompressed_optimizer_state_dict(checkpoint["optim_g"])
            )
            optim_d.load_state_dict(
                get_decompressed_optimizer_state_dict(checkpoint["optim_d"])
            )
            initial_iteration = checkpoint["iteration"]
        grad_balancer.load_state_dict(checkpoint["grad_balancer"])
        grad_scaler.load_state_dict(checkpoint["grad_scaler"])
    
    # Initialize VQ codebooks
    def wav_iterator(files):
        for file in files:
            wav, sr = torchaudio.load(file)
            wav = wav.to(device)
            if sr != h["in_sample_rate"]:
                wav = get_resampler(sr, h["in_sample_rate"], device)(wav)
            yield wav[:, None, :]
    
    if resume:
        net_g.enable_hook()
    else:
        net_g.initialize_vq([wav_iterator(files) for files in speaker_audio_files])
    
    # Schedulers
    scheduler_g = get_exponential_warmup_scheduler(
        optim_g, h["warmup_steps"], h["learning_rate_decay"]
    )
    scheduler_d = get_exponential_warmup_scheduler(
        optim_d, h["warmup_steps"], h["learning_rate_decay"]
    )
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message=r"Detected call of `lr_scheduler\.step\(\)` before `optimizer\.step\(\)`",
        )
        for _ in range(initial_iteration + 1):
            scheduler_g.step()
            scheduler_d.step()
    
    net_g.train()
    net_d.train()
    
    # Setup logging
    dict_scalars = defaultdict(list)
    quality_tester = QualityTester().eval().to(device)
    if skip_training:
        writer = None
    else:
        writer = SummaryWriter(out_dir)
        if not h["record_metrics"]:
            writer.add_scalar = lambda *args, **kwargs: None
            writer.add_histogram = lambda *args, **kwargs: None
        writer.add_text(
            "log",
            f"start training w/ {torch.cuda.get_device_name(device) if device.type == 'cuda' else device.type}.",
            initial_iteration,
        )
    if not resume:
        with open(out_dir / "config.json", "w", encoding="utf-8") as f:
            json.dump(dict(h), f, indent=4)
        if not is_notebook():
            shutil.copy(__file__, out_dir)
    
    # Training loop
    with (
        torch.profiler.profile(
            schedule=torch.profiler.schedule(wait=1500, warmup=10, active=5, repeat=1),
            on_trace_ready=torch.profiler.tensorboard_trace_handler(out_dir),
            record_shapes=True,
            with_stack=True,
            profile_memory=True,
            with_flops=True,
        )
        if h["profile"]
        else nullcontext()
    ) as profiler:
        for iteration in tqdm(range(initial_iteration, h["n_steps"]), desc="Training"):
            # Data
            try:
                batch = next(data_iter)
            except (NameError, StopIteration):
                data_iter = iter(training_loader)
                batch = next(data_iter)
            (
                clean_wavs,
                noisy_wavs_16k,
                slice_starts,
                speaker_ids,
                formant_shift_semitone,
            ) = map(lambda x: x.to(device, non_blocking=True), batch)
            
            # Training
            with torch.amp.autocast(_DEVICE_TYPE, enabled=h["use_amp"]):
                # Generator
                if h["compile_convnext"]:
                    ConvNeXtStack.forward = compiled_convnextstack_forward
                (
                    y,
                    y_hat,
                    y_hat_for_backward,
                    loss_loudness,
                    loss_mel,
                    loss_ap,
                    generator_stats,
                ) = net_g.forward_and_compute_loss(
                    noisy_wavs_16k[:, None, :],
                    speaker_ids,
                    formant_shift_semitone,
                    slice_start_indices=slice_starts,
                    slice_segment_length=h["segment_length"],
                    y_all=clean_wavs[:, None, :],
                    enable_loss_ap=h["grad_weight_ap"] != 0.0,
                )
                if h["compile_convnext"]:
                    ConvNeXtStack.forward = raw_convnextstack_forward
                assert y_hat.isfinite().all()
                assert loss_loudness.isfinite().all()
                assert loss_mel.isfinite().all()
                assert loss_ap.isfinite().all()
                
                # Discriminator
                loss_discriminator, loss_adv, loss_fm, discriminator_stats = (
                    net_d.forward_and_compute_loss(y, y_hat)
                )
                assert loss_discriminator.isfinite().all()
                assert loss_adv.isfinite().all()
                assert loss_fm.isfinite().all()
            
            # Backward
            for param in net_d.parameters():
                assert param.grad is None
            grad_scaler.scale(loss_discriminator).backward(
                retain_graph=True, inputs=list(net_d.parameters())
            )
            loss_discriminator = loss_discriminator.item()
            grad_scaler.unscale_(optim_d)
            if iteration % 5 == 0:
                grad_norm_d, d_grad_norm_stats = compute_grad_norm(net_d, True)
            else:
                grad_norm_d = math.nan
                d_grad_norm_stats = {}
            
            for param in net_g.parameters():
                assert param.grad is None
            gradient_balancer_stats = grad_balancer.backward(
                {
                    "loss_loudness": loss_loudness,
                    "loss_mel": loss_mel,
                    "loss_adv": loss_adv,
                    "loss_fm": loss_fm,
                }
                | ({"loss_ap": loss_ap} if h["grad_weight_ap"] else {}),
                y_hat_for_backward,
                grad_scaler,
                skip_update_ema=iteration > 10 and iteration % 5 != 0,
            )
            loss_loudness = loss_loudness.item()
            loss_mel = loss_mel.item()
            loss_adv = loss_adv.item()
            loss_fm = loss_fm.item()
            if h["grad_weight_ap"]:
                loss_ap = loss_ap.item()
            grad_scaler.unscale_(optim_g)
            if iteration % 5 == 0:
                grad_norm_g, g_grad_norm_stats = compute_grad_norm(net_g, True)
            else:
                grad_norm_g = math.nan
                g_grad_norm_stats = {}
            
            # Update
            grad_scaler.step(optim_g)
            optim_g.zero_grad(set_to_none=True)
            grad_scaler.step(optim_d)
            optim_d.zero_grad(set_to_none=True)
            grad_scaler.update()
            
            # Logging
            dict_scalars["loss_g/loss_loudness"].append(loss_loudness)
            dict_scalars["loss_g/loss_mel"].append(loss_mel)
            if h["grad_weight_ap"]:
                dict_scalars["loss_g/loss_ap"].append(loss_ap)
            dict_scalars["loss_g/loss_fm"].append(loss_fm)
            dict_scalars["loss_g/loss_adv"].append(loss_adv)
            dict_scalars["other/grad_scale"].append(grad_scaler.get_scale())
            dict_scalars["loss_d/loss_discriminator"].append(loss_discriminator)
            if math.isfinite(grad_norm_d):
                dict_scalars["other/gradient_norm_d"].append(grad_norm_d)
                for name, value in d_grad_norm_stats.items():
                    dict_scalars[f"~gradient_norm_d/{name}"].append(value)
            if math.isfinite(grad_norm_g):
                dict_scalars["other/gradient_norm_g"].append(grad_norm_g)
                for name, value in g_grad_norm_stats.items():
                    dict_scalars[f"~gradient_norm_g/{name}"].append(value)
            dict_scalars["other/lr_g"].append(scheduler_g.get_last_lr()[0])
            dict_scalars["other/lr_d"].append(scheduler_d.get_last_lr()[0])
            for k, v in generator_stats.items():
                dict_scalars[f"~loss_generator/{k}"].append(v)
            for k, v in discriminator_stats.items():
                dict_scalars[f"~loss_discriminator/{k}"].append(v)
            for k, v in gradient_balancer_stats.items():
                dict_scalars[f"~gradient_balancer/{k}"].append(v)
            
            if (iteration + 1) % 1000 == 0 or iteration == 0:
                for name, scalars in dict_scalars.items():
                    if scalars:
                        writer.add_scalar(
                            name, sum(scalars) / len(scalars), iteration + 1
                        )
                        scalars.clear()
                for name, param in net_g.named_parameters():
                    writer.add_histogram(f"weight/{name}", param, iteration + 1)
            
            # Evaluation
            if (iteration + 1) % h["evaluation_interval"] == 0 or iteration + 1 in {
                1,
                h["n_steps"],
            }:
                if device.type == "cuda":
                    torch.backends.cudnn.benchmark = False
                    torch.cuda.empty_cache()
                net_g.eval()
                
                dict_qualities_all = defaultdict(list)
                n_added_wavs = 0
                with torch.inference_mode():
                    for i, ((file, target_ids), pitch_shift_semitones) in enumerate(
                        zip(test_filelist, test_pitch_shifts)
                    ):
                        source_wav, sr = torchaudio.load(file)
                        source_wav = source_wav.to(device)
                        if sr != h["in_sample_rate"]:
                            source_wav = get_resampler(sr, h["in_sample_rate"], device)(
                                source_wav
                            )
                        source_wav = source_wav.to(device)
                        original_source_wav_length = source_wav.size(1)
                        
                        if source_wav.size(1) % h["in_sample_rate"] == 0:
                            padded_source_wav = source_wav
                        else:
                            padded_source_wav = F.pad(
                                source_wav,
                                (
                                    0,
                                    h["in_sample_rate"]
                                    - source_wav.size(1) % h["in_sample_rate"],
                                ),
                            )
                        
                        converted = net_g(
                            padded_source_wav[[0] * len(target_ids), None],
                            torch.tensor(target_ids, device=device),
                            torch.tensor(
                                [0.0] * len(target_ids), device=device
                            ),
                            torch.tensor(
                                [float(p) for p in pitch_shift_semitones], device=device
                            ),
                        ).squeeze_(1)[:, : original_source_wav_length // 160 * 240]
                        
                        if i < 12:
                            if iteration == 0:
                                writer.add_audio(
                                    f"source/y_{i:02d}",
                                    source_wav,
                                    iteration + 1,
                                    h["in_sample_rate"],
                                )
                            for d in range(
                                min(
                                    len(target_ids),
                                    1 + (12 - i - 1) // len(test_filelist),
                                )
                            ):
                                idx_in_batch = n_added_wavs % len(target_ids)
                                writer.add_audio(
                                    f"converted/y_hat_{i:02d}_{target_ids[idx_in_batch]:03d}_{pitch_shift_semitones[idx_in_batch]:+02d}",
                                    converted[idx_in_batch],
                                    iteration + 1,
                                    h["out_sample_rate"],
                                )
                                n_added_wavs += 1
                net_g.train()
                if device.type == "cuda":
                    torch.backends.cudnn.benchmark = True
                    torch.cuda.empty_cache()
    
    print("Training finished.")


def get_target_id_generator(n_speakers: int):
    """Generator for target IDs."""
    if n_speakers > 8:
        while True:
            order = list(range(n_speakers))
            rng.shuffle(order)
            yield from order
    else:
        while True:
            yield from range(n_speakers)


def get_compressed_optimizer_state_dict(optimizer: "torch.optim.Optimizer") -> dict:
    """Compress optimizer state dict to bfloat16."""
    state_dict = {}
    for k0, v0 in optimizer.state_dict().items():
        if k0 != "state":
            state_dict[k0] = v0
            continue
        state_dict[k0] = {}
        for k1, v1 in v0.items():
            state_dict[k0][k1] = {}
            for k2, v2 in v1.items():
                if isinstance(v2, torch.Tensor):
                    state_dict[k0][k1][k2] = v2.bfloat16()
                else:
                    state_dict[k0][k1][k2] = v2
    return state_dict


def get_decompressed_optimizer_state_dict(compressed_state_dict: dict) -> dict:
    """Decompress optimizer state dict back to float."""
    state_dict = {}
    for k0, v0 in compressed_state_dict.items():
        if k0 != "state":
            state_dict[k0] = v0
            continue
        state_dict[k0] = {}
        for k1, v1 in v0.items():
            state_dict[k0][k1] = {}
            for k2, v2 in v1.items():
                if isinstance(v2, torch.Tensor):
                    state_dict[k0][k1][k2] = v2.float()
                else:
                    state_dict[k0][k1][k2] = v2
    return state_dict


def compute_mean_f0(
    files: list[Path],
    method: Literal["dio", "harvest"] = "dio"
) -> float:
    """Compute mean F0 from audio files."""
    import numpy as np
    import pyworld
    import torch
    
    sum_log_f0 = 0.0
    n_frames = 0
    
    for file in files:
        wav, sr = torchaudio.load(file)
        if method == "dio":
            f0, _ = pyworld.dio(wav.ravel().numpy().astype(np.float64), sr)
        elif method == "harvest":
            f0, _ = pyworld.harvest(wav.ravel().numpy().astype(np.float64), sr)
        else:
            raise ValueError(f"Invalid method: {method}")
        f0 = f0[f0 > 0]
        sum_log_f0 += float(np.log(f0).sum())
        n_frames += len(f0)
    
    if n_frames == 0:
        return float("nan")
    mean_log_f0 = sum_log_f0 / n_frames
    return math.exp(mean_log_f0)


rng = random.Random(0)


if __name__ == "__main__":
    main()
