"""Training loop for Beatrice."""
import gc, json, shutil, gzip, math, os, warnings
from collections import defaultdict
from contextlib import nullcontext
from copy import deepcopy
from pathlib import Path
from pprint import pprint
from random import Random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchaudio
from torch.utils.tensorboard import SummaryWriter
from tqdm.auto import tqdm

from .extractors import PhoneExtractor, VectorQuantizer
from .pitch import PitchEstimator, extract_pitch_features
from .d4c import d4c
from .vocoder import Vocoder
from .discriminators import MultiPeriodDiscriminator
from .models import ConverterNetwork
from ._compat import is_notebook, repo_root
from .trainer_utils import GradBalancer, QualityTester
from .utils import (
    compute_loudness, slice_segments,
    compute_grad_norm, compute_mean_f0, get_resampler, convolve,
    get_compressed_optimizer_state_dict, get_decompressed_optimizer_state_dict,
)
from .dataset import WavDataset, AUDIO_FILE_SUFFIXES
from .config import (
    prepare_training_configs, prepare_training_configs_for_experiment,
    AttrDict, dict_default_hparams,
)
from . import _nan_repair_stats, _DEVICE_TYPE

def prepare_training():
    global _nan_repair_stats
    # 各種準備をする
    # 副作用として、出力ディレクトリと TensorBoard のログファイルなどが生成される

    # Anomaly detection for NaN debugging (enable via env var: BEATRICE_ANOMALY=1)
    enable_anomaly = os.environ.get("BEATRICE_ANOMALY", "0") == "1"
    if enable_anomaly:
        torch.autograd.set_detect_anomaly(True)
        print("WARNING: Autograd anomaly detection ENABLED (slow!)")

    forced_device = os.environ.get("BEATRICE_DEVICE", "").lower()
    if forced_device in ("cuda", "mps", "cpu"):
        device = torch.device(forced_device)
    elif torch.cuda.is_available():
        device = torch.device("cuda")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        device = torch.device("mps")
    else:
        device = torch.device("cpu")
    global _DEVICE_TYPE; _DEVICE_TYPE = device.type
    # Also update the module-level variable in beatrice_trainer so
    # __main__.py can read the correct device type
    import beatrice_trainer; beatrice_trainer._DEVICE_TYPE = device.type
    print(f"device={device}")

    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
        torch.backends.cuda.matmul.allow_tf32 = True
    elif device.type == "mps":
        if hasattr(torch.backends.mps, "set_per_process_memory_fraction"):
            torch.backends.mps.set_per_process_memory_fraction(1.0)

    (h, in_wav_dataset_dir, out_dir, resume, skip_training) = (
        prepare_training_configs_for_experiment
        if is_notebook()
        else prepare_training_configs
    )()

    print("config:")
    pprint(h)
    print()
    h = AttrDict(h)

    if device.type != "cuda":
        if h.use_amp:
            print("Warning: AMP disabled for non-CUDA device to prevent numerical instability.")
            h.use_amp = False
        if h.compile_convnext or h.compile_d4c or h.compile_discriminator:
            print("Note: torch.compile will use 'default' mode (CUDA graphs unavailable on non-CUDA device).")

    if not in_wav_dataset_dir.is_dir():
        raise ValueError(f"{in_wav_dataset_dir} is not found.")
    if resume:
        latest_checkpoint_file = out_dir / "checkpoint_latest.pt.gz"
        if not latest_checkpoint_file.is_file():
            raise ValueError(f"{latest_checkpoint_file} is not found.")
    else:
        if out_dir.is_dir():
            if (out_dir / "checkpoint_latest.pt.gz").is_file():
                raise ValueError(
                    f"{out_dir / 'checkpoint_latest.pt.gz'} already exists. "
                    "Please specify a different output directory, or use --resume option."
                )
            for file in out_dir.iterdir():
                if file.suffix == ".pt.gz":
                    raise ValueError(
                        f"{out_dir} already contains model files. "
                        "Please specify a different output directory."
                    )
        else:
            out_dir.mkdir(parents=True)

    in_ir_wav_dir = repo_root() / h.in_ir_wav_dir
    in_noise_wav_dir = repo_root() / h.in_noise_wav_dir
    in_test_wav_dir = repo_root() / h.in_test_wav_dir

    assert in_wav_dataset_dir.is_dir(), in_wav_dataset_dir
    assert out_dir.is_dir(), out_dir
    assert in_ir_wav_dir.is_dir(), in_ir_wav_dir
    assert in_noise_wav_dir.is_dir(), in_noise_wav_dir
    assert in_test_wav_dir.is_dir(), in_test_wav_dir

    # .wav または *.flac のファイルを再帰的に取得
    noise_files = sorted(
        list(in_noise_wav_dir.rglob("*.wav")) + list(in_noise_wav_dir.rglob("*.flac"))
    )
    if len(noise_files) == 0:
        raise ValueError(f"No audio data found in {in_noise_wav_dir}.")
    ir_files = sorted(
        list(in_ir_wav_dir.rglob("*.wav")) + list(in_ir_wav_dir.rglob("*.flac"))
    )
    if len(ir_files) == 0:
        raise ValueError(f"No audio data found in {in_ir_wav_dir}.")

    # TODO: 無音除去とか

    def get_training_filelist(in_wav_dataset_dir: Path):
        min_data_per_speaker = 1
        speakers: list[str] = []
        training_filelist: list[tuple[Path, int]] = []
        speaker_audio_files: list[list[Path]] = []
        for speaker_dir in sorted(in_wav_dataset_dir.iterdir()):
            if not speaker_dir.is_dir():
                continue
            candidates = []
            for wav_file in sorted(speaker_dir.rglob("*")):
                if (
                    not wav_file.is_file()
                    or wav_file.suffix.lower() not in AUDIO_FILE_SUFFIXES
                ):
                    continue
                candidates.append(wav_file)
            if len(candidates) >= min_data_per_speaker:
                speaker_id = len(speakers)
                speakers.append(speaker_dir.name)
                training_filelist.extend([(file, speaker_id) for file in candidates])
                speaker_audio_files.append(candidates)
        return speakers, training_filelist, speaker_audio_files

    speakers, training_filelist, speaker_audio_files = get_training_filelist(
        in_wav_dataset_dir
    )
    n_speakers = len(speakers)
    if n_speakers == 0:
        raise ValueError(f"No speaker data found in {in_wav_dataset_dir}.")
    print(f"{n_speakers=}")
    for i, speaker in enumerate(speakers):
        print(f"  {i:{len(str(n_speakers - 1))}d}: {speaker}")
    print()
    print(f"{len(training_filelist)=}")

    def get_test_filelist(
        in_test_wav_dir: Path, n_speakers: int
    ) -> list[tuple[Path, list[int]]]:
        max_n_test_files = 1000
        test_filelist = []
        rng = Random(42)

        def get_target_id_generator():
            if n_speakers > 8:
                while True:
                    order = list(range(n_speakers))
                    rng.shuffle(order)
                    yield from order
            else:
                while True:
                    yield from range(n_speakers)

        target_id_generator = get_target_id_generator()
        for file in sorted(in_test_wav_dir.iterdir())[:max_n_test_files]:
            if file.suffix.lower() not in AUDIO_FILE_SUFFIXES:
                continue
            target_ids = [next(target_id_generator) for _ in range(min(8, n_speakers))]
            test_filelist.append((file, target_ids))
        return test_filelist

    test_filelist = get_test_filelist(in_test_wav_dir, n_speakers)
    if len(test_filelist) == 0:
        warnings.warn(f"No audio data found in {test_filelist}.")
    print(f"{len(test_filelist)=}")
    for file, target_ids in test_filelist[:12]:
        print(f"  {file}, {target_ids}")
    if len(test_filelist) > 12:
        print("  ...")
    print()

    # データ

    training_dataset = WavDataset(
        training_filelist,
        in_sample_rate=h.in_sample_rate,
        out_sample_rate=h.out_sample_rate,
        wav_length=h.wav_length,
        segment_length=h.segment_length,
        noise_files=noise_files,
        ir_files=ir_files,
        augmentation_snr_candidates=h.augmentation_snr_candidates,
        augmentation_formant_shift_probability=h.augmentation_formant_shift_probability,
        augmentation_formant_shift_semitone_min=h.augmentation_formant_shift_semitone_min,
        augmentation_formant_shift_semitone_max=h.augmentation_formant_shift_semitone_max,
        augmentation_reverb_probability=h.augmentation_reverb_probability,
        augmentation_lpf_probability=h.augmentation_lpf_probability,
        augmentation_lpf_cutoff_freq_candidates=h.augmentation_lpf_cutoff_freq_candidates,
    )
    num_workers = min(h.num_workers, os.cpu_count() or 1)
    training_loader = torch.utils.data.DataLoader(
        training_dataset,
        num_workers=num_workers,
        collate_fn=training_dataset.collate,
        shuffle=True,
        sampler=None,
        batch_size=h.batch_size,
        pin_memory=num_workers > 0,
        drop_last=True,
        persistent_workers=num_workers > 0,
    )

    print("Computing mean F0s of target speakers...", end="")
    speaker_f0s = []
    for speaker, files in enumerate(speaker_audio_files):
        if len(files) > 10:
            files = Random(42).sample(files, 10)
        f0 = compute_mean_f0(files)
        speaker_f0s.append(f0)
        if speaker % 5 == 0:
            print()
        print(f"  {speaker:3d}: {f0:.1f}Hz", end=",")
    print()
    print("Done.")
    print("Computing pitch shifts for test files...")
    test_pitch_shifts = []
    source_f0s = []
    for i, (file, target_ids) in enumerate(
        tqdm(test_filelist, desc="Computing pitch shifts")
    ):
        source_f0 = compute_mean_f0([file], method="harvest")
        source_f0s.append(source_f0)
        if math.isnan(source_f0):
            test_pitch_shifts.append([0] * len(target_ids))
            continue
        pitch_shifts = []
        for target_id in target_ids:
            target_f0 = speaker_f0s[target_id]
            if target_f0 != target_f0:
                pitch_shift = 0
            else:
                pitch_shift = int(round(12.0 * math.log2(target_f0 / source_f0)))
            pitch_shifts.append(pitch_shift)
        test_pitch_shifts.append(pitch_shifts)
    print("Done.")

    # モデルと最適化

    phone_extractor = PhoneExtractor().to(device).eval().requires_grad_(False)
    phone_extractor_checkpoint = torch.load(
        repo_root() / h.phone_extractor_file, map_location="cpu", weights_only=True
    )
    print(
        phone_extractor.load_state_dict(
            phone_extractor_checkpoint["phone_extractor"], strict=False
        )
    )
    del phone_extractor_checkpoint

    # PitchEstimator runs on CPU internally (FFT ops unstable on MPS).
    # Keep it on CPU — it moves weights to CPU anyway during forward().
    pitch_estimator = PitchEstimator().eval().requires_grad_(False)
    pitch_estimator_checkpoint = torch.load(
        repo_root() / h.pitch_estimator_file, map_location="cpu", weights_only=True
    )
    print(
        pitch_estimator.load_state_dict(pitch_estimator_checkpoint["pitch_estimator"])
    )
    del pitch_estimator_checkpoint

    net_g = ConverterNetwork(
        phone_extractor,
        pitch_estimator,
        n_speakers,
        h.pitch_bins,
        h.hidden_channels,
        h.vq_topk,
        h.training_time_vq,
        h.phone_noise_ratio,
        h.floor_noise_level,
    ).to(device)
    net_d = MultiPeriodDiscriminator(san=h.san).to(device)

    optim_g = torch.optim.AdamW(
        net_g.parameters(),
        h.learning_rate_g,
        betas=h.adam_betas,
        eps=h.adam_eps,
    )
    optim_d = torch.optim.AdamW(
        net_d.parameters(),
        h.learning_rate_d,
        betas=h.adam_betas,
        eps=h.adam_eps,
    )

    grad_scaler = torch.amp.GradScaler(_DEVICE_TYPE, enabled=h.use_amp)
    grad_balancer = GradBalancer(
        weights={
            "loss_loudness": h.grad_weight_loudness,
            "loss_mel": h.grad_weight_mel,
            "loss_adv": h.grad_weight_adv,
            "loss_fm": h.grad_weight_fm,
        }
        | ({"loss_ap": h.grad_weight_ap} if h.grad_weight_ap else {}),
        ema_decay=h.grad_balancer_ema_decay,
    )
    resample_to_in_sample_rate = torchaudio.transforms.Resample(
        h.out_sample_rate, h.in_sample_rate
    ).to(device)

    # チェックポイント読み出し

    initial_iteration = 0
    if resume:  # 学習再開
        checkpoint_file = latest_checkpoint_file
    elif h.pretrained_file is not None:  # ファインチューニング
        checkpoint_file = repo_root() / h.pretrained_file
    else:  # 事前学習
        checkpoint_file = None

    if checkpoint_file is not None:
        with gzip.open(checkpoint_file, "rb") as f:
            checkpoint = torch.load(f, map_location="cpu", weights_only=True)
        if not resume and not skip_training:  # ファインチューニング
            initial_speaker_embedding = checkpoint["net_g"]["embed_speaker.weight"][:1]
            initial_speaker_embedding_for_cross_attention = checkpoint["net_g"][
                "key_value_speaker_embedding.weight"
            ][:1]
            checkpoint["net_g"]["embed_speaker.weight"] = initial_speaker_embedding[
                [0] * n_speakers
            ]
            checkpoint["net_g"]["key_value_speaker_embedding.weight"] = (
                initial_speaker_embedding_for_cross_attention[[0] * n_speakers]
            )
            checkpoint["net_g"]["vq.codebooks"] = checkpoint["net_g"]["vq.codebooks"][
                [0] * n_speakers
            ]
        print(net_g.load_state_dict(checkpoint["net_g"], strict=False))
        print(net_d.load_state_dict(checkpoint["net_d"], strict=False))
        if resume or skip_training:
            optim_g.load_state_dict(
                get_decompressed_optimizer_state_dict(checkpoint["optim_g"])
            )
            optim_d.load_state_dict(
                get_decompressed_optimizer_state_dict(checkpoint["optim_d"])
            )
            initial_iteration = checkpoint["iteration"]
        grad_balancer.load_state_dict(checkpoint["grad_balancer"])
        grad_scaler.load_state_dict(checkpoint["grad_scaler"])

    def wav_iterator(files):
        for file in files:
            wav, sr = torchaudio.load(file)
            wav = wav.to(device)
            if sr != h.in_sample_rate:
                wav = get_resampler(sr, h.in_sample_rate, device)(wav)
            yield wav[:, None, :]

    if resume:
        net_g.enable_hook()
    else:
        net_g.initialize_vq([wav_iterator(files) for files in speaker_audio_files])

    # スケジューラ

    def get_exponential_warmup_scheduler(
        optimizer: torch.optim.Optimizer,
        warmup_epochs: int,
        decay: float,
    ) -> torch.optim.lr_scheduler.LambdaLR:
        def lr_lambda(current_epoch: int) -> float:
            if current_epoch < warmup_epochs:
                return current_epoch / warmup_epochs
            else:
                return decay ** (current_epoch - warmup_epochs)

        return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

    scheduler_g = get_exponential_warmup_scheduler(
        optim_g, h.warmup_steps, h.learning_rate_decay
    )
    scheduler_d = get_exponential_warmup_scheduler(
        optim_d, h.warmup_steps, h.learning_rate_decay
    )
    # Directly set scheduler state instead of replaying O(n) steps
    if initial_iteration > 0:
        _warmup = h.warmup_steps
        _decay = h.learning_rate_decay
        def _lr_lambda(epoch):
            if epoch < _warmup:
                return epoch / _warmup
            return _decay ** (epoch - _warmup)
        _lr_g = _lr_lambda(initial_iteration) * h.learning_rate_g
        _lr_d = _lr_lambda(initial_iteration) * h.learning_rate_d
        for pg in optim_g.param_groups:
            pg['lr'] = _lr_g
        for pg in optim_d.param_groups:
            pg['lr'] = _lr_d
        # Update scheduler internal step count
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message=r"Detected call of `lr_scheduler\.step\(\)` before `optimizer\.step\(\)`\.",
            )
            scheduler_g._step_count = initial_iteration
            scheduler_d._step_count = initial_iteration
            # Step once to sync scheduler state
            scheduler_g.step()
            scheduler_d.step()

    net_g.train()
    net_d.train()

    # ログとか

    dict_scalars = defaultdict(list)
    quality_tester = QualityTester().eval().to(device)
    if skip_training:
        writer = None
    else:
        writer = SummaryWriter(out_dir)
        if not h.record_metrics:
            writer.add_scalar = lambda *args, **kwargs: None
            writer.add_histogram = lambda *args, **kwargs: None
        writer.add_text(
            "log",
            f"start training w/ {torch.cuda.get_device_name(device) if device.type == 'cuda' else device.type}.",
            initial_iteration,
        )
    if not resume:
        with open(out_dir / "config.json", "w", encoding="utf-8") as f:
            json.dump(dict(h), f, indent=4)
        if not is_notebook():
            shutil.copy(__file__, out_dir)

    return (
        device,
        in_wav_dataset_dir,
        h,
        out_dir,
        speakers,
        test_filelist,
        training_loader,
        speaker_f0s,
        test_pitch_shifts,
        phone_extractor,
        pitch_estimator,
        net_g,
        net_d,
        optim_g,
        optim_d,
        grad_scaler,
        grad_balancer,
        resample_to_in_sample_rate,
        initial_iteration,
        scheduler_g,
        scheduler_d,
        dict_scalars,
        quality_tester,
        writer,
    )


