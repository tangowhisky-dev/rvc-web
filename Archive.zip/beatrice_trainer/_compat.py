"""Shared compatibility helpers and import-time side-effects."""

import warnings
from pathlib import Path

import torch
import torchaudio

# ── import-time side-effects (formerly duplicated in every module) ────────

warnings.filterwarnings("ignore", message=r"An output with one or more elements was resized")
warnings.filterwarnings("ignore", message=r"`torch.nn.utils.weight_norm` is deprecated")

if hasattr(torchaudio, "list_audio_backends"):
    assert "soundfile" in torchaudio.list_audio_backends()

if not hasattr(torch.amp, "GradScaler"):
    class _FallbackGradScaler:
        def __init__(s, dt, *a, **k):
            import torch.cuda.amp; s._s = torch.cuda.amp.GradScaler(*a, **k)
        def scale(s, l): return s._s.scale(l)
        def unscale_(s, o): return s._s.unscale_(o)
        def step(s, o): return s._s.step(o)
        def update(s): return s._s.update()
        def get_scale(s): return s._s.get_scale()
        def load_state_dict(s, d): return s._s.load_state_dict(d)
        def state_dict(s): return s._s.state_dict()
    torch.amp.GradScaler = _FallbackGradScaler

# ── shared constants / helpers ────────────────────────────────────────────

PARAPHERNALIA_VERSION = "2.0.0-rc.0"


def is_notebook():
    return "get_ipython" in globals()


def repo_root():
    d = Path.cwd() / "dummy" if is_notebook() else Path(__file__)
    assert d.is_absolute()
    for d in d.parents:
        if (d / ".git").is_dir():
            return d
    raise RuntimeError("Repository root not found.")
