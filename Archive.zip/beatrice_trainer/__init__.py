"""Beatrice Trainer — modular voice conversion training package."""
__version__ = "2.0.0-rc.0"

# Shared state
_nan_repair_stats = {
    "pitch_features_nan_batches": 0,
    "pitch_features_nan_elements": 0,
    "y_hat_nan_batches": 0,
    "y_hat_nan_elements": 0,
    "loss_nan_batches": {"loudness": 0, "mel": 0, "ap": 0, "disc": 0, "adv": 0, "fm": 0},
    "iterations_skipped_forward_nan": 0,
    "iterations_skipped_grad_nan": 0,
    "weight_rollbacks": 0,
}
_DEVICE_TYPE = "cuda"

# Import everything from modules
from ._compat import is_notebook, repo_root, PARAPHERNALIA_VERSION
from .config import dict_default_hparams
from .modules import (
    CausalConv1d, WSConv1d, WSLinear, CrossAttention,
    ConvNeXtBlock, ConvNeXtStack,
    dump_params, dump_layer,
)
from .extractors import (
    FeatureExtractor, FeatureProjection, PhoneExtractor, VectorQuantizer,
)
from .pitch import extract_pitch_features, PitchEstimator
from .d4c import (
    overlap_add, generate_noise, interp, linear_smoothing, dc_correction,
    nuttall, get_windowed_waveform, get_centroid, get_static_centroid,
    get_smoothed_power_spec, get_static_group_delay, get_coarse_aperiodicity,
    d4c_love_train, d4c_general_body, d4c,
)
from .vocoder import Vocoder
from .discriminators import SANConv2d, DiscriminatorP, DiscriminatorR, MultiPeriodDiscriminator
from .models import ConverterNetwork
from .dataset import WavDataset, augment_audio
from .trainer_utils import GradBalancer, QualityTester
from .utils import (
    compute_loudness, slice_segments, _normalize,
    compute_grad_norm, compute_mean_f0, get_resampler, convolve,
    get_butterworth_lpf, get_compressed_optimizer_state_dict,
    get_decompressed_optimizer_state_dict,
)
from .config import (
    AttrDict, prepare_training_configs, prepare_training_configs_for_experiment,
)
from .training import prepare_training
