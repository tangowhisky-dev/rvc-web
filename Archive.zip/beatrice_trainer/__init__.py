"""Beatrice Voice Conversion Trainer.

A PyTorch-based voice conversion system with:
- Phone extraction using ConvNeXt backbone
- Pitch estimation using WORLD-like features
- Neural vocoder with cross-attention
- Multi-scale discriminators
"""

__version__ = "2.0.0-rc.0"
__all__ = ["prepare_training", "ConverterNetwork", "PhoneExtractor", "PitchEstimator", "Vocoder"]
