"""Configuration handling and default hyperparameters.

Contains default hyperparameters and config loading functions.
"""

import argparse
import json
import warnings
from copy import deepcopy
from pathlib import Path
from typing import Optional


def_default_hparams: dict = {
    # training
    "learning_rate_g": 5e-5,
    "learning_rate_d": 5e-5,
    "learning_rate_decay": 0.999999,
    "adam_betas": [0.8, 0.99],
    "adam_eps": 1e-6,
    "batch_size": 8,
    "grad_weight_loudness": 1.0,
    "grad_weight_mel": 50.0,
    "grad_weight_ap": 100.0,
    "grad_weight_adv": 150.0,
    "grad_weight_fm": 150.0,
    "grad_balancer_ema_decay": 0.995,
    "use_amp": True,
    "num_workers": 16,
    "n_steps": 10000,
    "warmup_steps": 5000,
    "evaluation_interval": 2000,
    "save_interval": 2000,
    "in_sample_rate": 16000,
    "out_sample_rate": 24000,
    "wav_length": 4 * 24000,  # 4s
    "segment_length": 100,  # 1s
    "phone_noise_ratio": 0.5,
    "vq_topk": 4,
    "training_time_vq": "none",
    "floor_noise_level": 1e-3,
    "record_metrics": False,
    # augmentation
    "augmentation_snr_candidates": [20.0, 25.0, 30.0, 35.0, 40.0, 45.0],
    "augmentation_formant_shift_probability": 0.5,
    "augmentation_formant_shift_semitone_min": -3.0,
    "augmentation_formant_shift_semitone_max": 3.0,
    "augmentation_reverb_probability": 0.5,
    "augmentation_lpf_probability": 0.2,
    "augmentation_lpf_cutoff_freq_candidates": [2000.0, 3000.0, 4000.0, 6000.0],
    # data
    "phone_extractor_file": "assets/pretrained/122_checkpoint_03000000.pt",
    "pitch_estimator_file": "assets/pretrained/104_3_checkpoint_00300000.pt",
    "in_ir_wav_dir": "assets/ir",
    "in_noise_wav_dir": "assets/noise",
    "in_test_wav_dir": "assets/test",
    "pretrained_file": None,
    # model
    "pitch_bins": 448,
    "hidden_channels": 256,
    "san": False,
    "compile_convnext": False,
    "compile_d4c": False,
    "compile_discriminator": False,
    "profile": False,
}


def prepare_training_configs_for_experiment(
    repo_root: Optional[Path] = None
) -> tuple[dict, Path, Path, bool, bool]:
    """Prepare configs for experiment mode (notebook context).
    
    Args:
        repo_root: Optional path to repository root. If None, auto-detect.
    
    Returns:
        Tuple of (hparams, in_wav_dataset_dir, out_dir, resume, skip_training)
    """
    h = deepcopy(dict_default_hparams)
    
    if repo_root is None:
        # Auto-detect repo root
        import os
        d = Path(__file__).parent
        while not (d / ".git").is_dir():
            d = d.parent
        repo_root = d
    
    in_wav_dataset_dir = repo_root / "../../data/processed/libritts_r_200"
    
    # Determine output directory based on notebook name
    try:
        import ipynbname
        notebook_name = ipynbname.name()
    except (FileNotFoundError, ImportError):
        try:
            from IPython import get_ipython
            notebook_name = Path(get_ipython().user_ns["__vsc_ipynb_file__"]).name
        except (FileNotFoundError, KeyError, ImportError):
            notebook_name = "experiment"
    
    out_dir = repo_root / "notebooks" / notebook_name.split(".")[0].split("_")[0]
    
    return h, in_wav_dataset_dir, out_dir, False, False


def prepare_training_configs(
    data_dir: Optional[Path] = None,
    out_dir: Optional[Path] = None,
    resume: bool = False,
    config_path: Optional[Path] = None
) -> tuple[dict, Path, Path, bool, bool]:
    """Prepare training configurations.
    
    Args:
        data_dir: Directory containing training data
        out_dir: Output directory for checkpoints
        resume: Whether to resume training
        config_path: Path to JSON config file
    
    Returns:
        Tuple of (hparams, in_wav_dataset_dir, out_dir, resume, skip_training)
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--data_dir", type=Path, help="training data directory")
    parser.add_argument("-o", "--out_dir", type=Path, help="output directory")
    parser.add_argument("-r", "--resume", action="store_true", help="resume training")
    parser.add_argument("-c", "--config", type=Path, help="path to config file")
    args = parser.parse_args()
    
    # Load config
    if config_path is None:
        h = deepcopy(dict_default_hparams)
    else:
        with open(config_path, encoding="utf-8") as f:
            h = json.load(f)
    
    # Validate and fill defaults
    for key in def_default_hparams.keys():
        if key not in h:
            h[key] = def_default_hparams[key]
            warnings.warn(f"{key} not in config, using default: {h[key]}")
    
    # Set data_dir
    if args.data_dir is not None:
        in_wav_dataset_dir = args.data_dir
    elif "data_dir" in h:
        in_wav_dataset_dir = Path(h["data_dir"])
        del h["data_dir"]
    else:
        raise ValueError("data_dir must be specified")
    
    # Set out_dir
    if args.out_dir is not None:
        out_dir = args.out_dir
    elif "out_dir" in h:
        out_dir = Path(h["out_dir"])
        del h["out_dir"]
    else:
        raise ValueError("out_dir must be specified")
    
    # Remove unknown keys
    for key in list(h.keys()):
        if key not in def_default_hparams:
            warnings.warn(f"Unknown key '{key}' ignored")
            del h[key]
    
    return h, in_wav_dataset_dir, out_dir, resume, False
