#!/bin/bash

# Beatrice Trainer Batch Processing Script
# Usage: ./run_beatrice.sh <input_file_or_folder> <output_folder> <num_iterations> [speaker_name]
#
# Args:
#   input_file_or_folder: Path to audio file OR directory containing audio files
#   output_folder: Where checkpoints will be saved
#   num_iterations: Number of training iterations
#   speaker_name: Optional speaker name (e.g., "speaker_001" or "speaker_002")
#                 If not provided, auto-generates from filename
#
# The script creates speaker-named folders containing 4-second chunks.
# The Beatrice trainer expects:
#   data_dir/
#     speaker_001/
#       chunk_000000.wav
#       ...

set -e  # Exit on error

# Check arguments
if [ $# -lt 3 ]; then
    echo "Usage: $0 <input_file_or_folder> <output_folder> <num_iterations> [speaker_name]"
    echo "  input_file_or_folder: Path to audio file or directory containing audio files"
    echo "  output_folder: Where checkpoints will be saved"
    echo "  num_iterations: Number of training iterations"
    echo "  speaker_name: Optional speaker identifier (e.g., speaker_001)"
    exit 1
fi

INPUT_PATH="$1"
OUTPUT_FOLDER="$2"
NUM_ITERATIONS="$3"
SPEAKER_NAME="${4:-}"

# Resolve relative paths to absolute
if [[ "$INPUT_PATH" != /* ]]; then
    INPUT_PATH="$(pwd)/$INPUT_PATH"
fi
if [[ "$OUTPUT_FOLDER" != /* ]]; then
    OUTPUT_FOLDER="$(pwd)/$OUTPUT_FOLDER"
fi

# Validate inputs and find audio file
LONG_AUDIO=""
if [ -f "$INPUT_PATH" ]; then
    # Single file provided
    LONG_AUDIO="$INPUT_PATH"
    echo "Processing single file: $LONG_AUDIO"
elif [ -d "$INPUT_PATH" ]; then
    # Directory provided - find audio file (any size for flexibility)
    LONG_AUDIO=$(find "$INPUT_PATH" -type f \( -name "*.wav" -o -name "*.mp3" -o -name "*.flac" -o -name "*.ogg" \) 2>/dev/null | head -n 1)

    if [ -z "$LONG_AUDIO" ]; then
        echo "Error: No audio file found in $INPUT_PATH"
        echo "Expected files: .wav, .mp3, .flac, .ogg"
        exit 1
    fi
    echo "Found audio file in directory: $LONG_AUDIO"
else
    echo "Error: Input does not exist: $INPUT_PATH"
    exit 1
fi

echo "========================================"
echo "Beatrice Trainer Batch Processing"
echo "========================================"
echo "Input audio: $LONG_AUDIO"
echo "Output folder: $OUTPUT_FOLDER"
echo "Iterations: $NUM_ITERATIONS"
if [ -n "$SPEAKER_NAME" ]; then
    echo "Speaker: $SPEAKER_NAME"
fi
echo "========================================"

# Create output directories
mkdir -p "$OUTPUT_FOLDER/checkpoints"
mkdir -p "$OUTPUT_FOLDER/logs"

# Detect and activate conda environment
if command -v conda &> /dev/null; then
    eval "$(conda shell.bash hook 2>/dev/null)" 2>/dev/null || true
    if conda env list 2>/dev/null | grep -q "rvc"; then
        conda activate rvc
        PYTHON_BIN=$(which python3)
        echo "Activated conda 'rvc' environment: $PYTHON_BIN"
    fi
fi

# Fallback: try common python paths
if [ -z "$PYTHON_BIN" ] || ! command -v "$PYTHON_BIN" &> /dev/null; then
    if [ -f "/opt/miniconda3/envs/rvc/bin/python3" ]; then
        PYTHON_BIN="/opt/miniconda3/envs/rvc/bin/python3"
    elif [ -f "$HOME/miniconda3/envs/rvc/bin/python3" ]; then
        PYTHON_BIN="$HOME/miniconda3/envs/rvc/bin/python3"
    elif command -v python3 &> /dev/null; then
        PYTHON_BIN=$(which python3)
    else
        echo "Error: Python not found. Please ensure conda 'rvc' environment is installed."
        exit 1
    fi
    echo "Using Python: $PYTHON_BIN"
fi

echo "Using Python: $PYTHON_BIN"
BACKEND=$("$PYTHON_BIN" -c "import torch; print('cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu')" 2>/dev/null || echo "cpu")
echo "Detected backend: $BACKEND"
echo ""

# Step 1: Split audio into 4-second chunks
echo "Step 1: Splitting audio into 4-second chunks..."
echo "----------------------------------------"
echo "Input: $LONG_AUDIO"
echo "Output: $OUTPUT_FOLDER/chunks"
echo ""

# Run chunking script with speaker name
"$PYTHON_BIN" chunk_audio.py "$LONG_AUDIO" "$OUTPUT_FOLDER/chunks" "$SPEAKER_NAME" --chunk-duration 4.0

CHUNK_COUNT=$(find "$OUTPUT_FOLDER/chunks" -name "*.wav" -type f 2>/dev/null | wc -l | tr -d ' ')
echo "Created $CHUNK_COUNT chunks"

# Step 2: Run Beatrice training
echo ""
echo "Step 2: Running Beatrice training..."
echo "----------------------------------------"

# Create a temporary config file
CONFIG_FILE="$OUTPUT_FOLDER/config.json"
cat > "$CONFIG_FILE" << EOF
{
    "data_dir": "$OUTPUT_FOLDER/chunks",
    "out_dir": "$OUTPUT_FOLDER/checkpoints",
    "num_workers": 0,
    "n_steps": $NUM_ITERATIONS,
    "batch_size": 8,
    "learning_rate_g": 5e-5,
    "learning_rate_d": 5e-5,
    "save_interval": 500,
    "evaluation_interval": 200,
    "in_sample_rate": 16000,
    "out_sample_rate": 24000,
    "wav_length": 96000,
    "segment_length": 100,
    "phone_extractor_file": "assets/pretrained/122_checkpoint_03000000.pt",
    "pitch_estimator_file": "assets/pretrained/104_3_checkpoint_00300000.pt",
    "in_ir_wav_dir": "assets/ir",
    "in_noise_wav_dir": "assets/noise",
    "in_test_wav_dir": "assets/test"
}
EOF

echo "Config file created: $CONFIG_FILE"

# Run the trainer using detected Python
"$PYTHON_BIN" -m beatrice_trainer -c "$CONFIG_FILE"

# Step 3: Cleanup (optional)
echo ""
echo "Step 3: Cleaning up..."
echo "----------------------------------------"

# Remove config file
rm -f "$CONFIG_FILE"

echo ""
echo "========================================"
echo "Training completed!"
echo "========================================"
echo "Checkpoints saved to: $OUTPUT_FOLDER/checkpoints"
echo "Latest checkpoint: $OUTPUT_FOLDER/checkpoints/checkpoint_latest.pt.gz"
echo "========================================"
